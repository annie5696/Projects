---
title: Application Task 1
---

## The Workflow

Due by 11:59 pm Sunday, Sept. 8th.

### Overview
This assignment will reinforce the [project workflow](https://happygitwithr.com/new-github-first.html) with RStudio that we will be using throughout this course.
If you run into any issues, we should be able to get them worked out.

You will be submitting three items: [1] a README.md and [2] an R Markdown report through GitHub, and [3] a reflection on Bb.

#### Evaluation

Tasks [1] and [2] will each be evaluated using the [Application Tasks Grading Standards](https://sta518.github.io/syllabus/assessment/#application-tasks-1).
Task [3] will be evaluated using the [Meeting Preparation Grading Standards](https://sta518.github.io/syllabus/assessment/#meeting-preparation-1).

Your overall Application Task 1 grade will be based on the following criteria:

- Excellent (**E**): Each task earned an Excellent of Satisfactory, including one Excellent.
- Satisfactory (**S**): Each task earned a Satisfactory.
- Progressing (**P**): Each task earned a Satisfactory or Progressing.
- Incomplete (**I**): At least one task earn an Incomplete or was not submit.

### Create Your `application01` Repo

GitHub Classroom will automatically make a repository for you, called `application-your_github_username`, for you to work on your assignment.
Follow these instructions to get the repo:

1. Sign-in to [Bb](https://mybb.gvsu.edu)
2. Go to the **Application Task 1** assignment page.

Here, you will find a url leading to a page on GitHub Classroom.
Visit this page and follow the instructions.
When you obtain your repository, it should contain a copy of this `application01-instructions.md` file, a blank `README.md` file, and a starter `application01-exploration.Rmd` file.

#### 1. Edit `README.md` 

Your task here is to edit the `README.md` file in your repository to contain a sample of GitHub-flavored markdown features.
Specifically, your README should contain:

- A brief description as to what the repo is, so that an unknown visitor landing on the repo can orient themselves
You should also help the visitor navigate your repository (in whatever way you think is most appropriate).
- An introduction to yourself.
Here you should elaborate and showcase various GitHub-flavored markdown features.

Remember the resources you were directed to view during your work in the class activities and Meeting Preparations.
These are also organized in the [Additional Resources/Markdown](https://sta518.github.io/resources/markdown/) section of this site.

You can edit the README in your browser like we did in class, but I encourage you to experiment with editing it from within RStudio.
**FYI, this will be a private repo - only you and I will be able to see it.**

#### 2. Exploration with R Markdown

Edit the R Markdown document.
This task explores a dataset, similarly to what we did in-class with the [datasaraus](https://sta518.github.io/learningmodules/lm1/rstudio_rmarkdown/activity0102) exploration.
Your final submission should include both text and code intertwined.
If you simply mimicked the in-class activity, this would be considered *sufficient*.

You will be using the [`gapminder`](https://www.youtube.com/watch?v=jbkSRLYSojo) data for this assignment.
For this task, commit *only* your completed `.Rmd` file and push it to GitHub.

#### 3. Reflection
  
After you have completed [1] and [2] above, go back to the **Application Task 1** assignment page on [Bb](https://mybb.gvsu.edu).
You will submit your reflection here that minimally includes:

- A link to your homework repository
- A description of how you got the changes into README.md on GitHub
    - Did you use the browser at github.com?
    - Did you pull, edit in RStudio, save, commit, push to github.com?
- How did working on the R Markdown document go?
- Reflect on what was hard/easy, problems you came across and how you solved them (helpful tutorials you read, etc.)