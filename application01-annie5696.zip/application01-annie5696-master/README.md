### Application01

**1.** A **repository** is like a folder where we can store    our         files, projects and can track the history of     the file. We can discuss and manage our project's work by owner or whoever has the access to the repository by     simply sharing ownership of repositories with other people    in an organization. This help to work collaboratively. Here is a brief description of my own repo. 

   + I first collaborated on repo name by accepting the invitation  [**application01-annie5696**](https://github.com/sta518/application01-annie5696)  
   + On the first Landing pages of the repo, we can see the primary repo name on left top or in the URL after "/" ([github.com/**sta518**](https://github.com/sta518)), which has collection of all other reposiory and we can see by their repo name. Under this, my repo is ([github.com/sta518/**application01-annie5696**](https://github.com/sta518/application01-annie5696))
   +  We can see folders, which can be public or private and accessible if shared to limited person including you or only you. 
Here, [**sta518/application01-annie5696**](https://github.com/sta518/application01-annie5696)  is my folder from the collection of all other repo. 
   + Under this file [**sta518/application01-annie5696**](https://github.com/sta518/application01-annie5696) , options like how many commit, branch and who have the access to this repo ( _contributer's information on hover_). These information are stored on top of the table. Below the orange line, informations like upload, finding any files, clone etc are also available. The following process can be accessed through this repo which are explained below.
   
     + If we go to [**application01.exploration.Rmd**](https://github.com/sta518/application01-annie5696/blob/master/application01-exploration.Rmd) file, There we can see the embedded R code chunks that can be run, and allows output to be included in the document. There is another self build html file, which automatically generates html code whatever we type in `.Rmd file`. You can see this by clicking    [**README.html**](https://github.com/sta518/application01-annie5696/blob/master/README.html) here.
     + Similarly, there are other files in the repo, [**README.md**](https://github.com/sta518/application01-annie5696/blob/master/README.md), where I have written all this information. 
     + Likewise,[**application01-exploration.html**](https://github.com/sta518/application01-annie5696/blob/master/application01-exploration.html)  which is also self build html file. This is similar to `README.html` but of `application-exploration.html`  
     + Lastly, [**instruction_file**](https://github.com/sta518/application01-annie5696/blob/master/assignment01-instructions.md)  which gives information on the workflow.
        
        
**2.**
Hello!  &#9786; I am **Anisha Shrestha**, a LEO  &#9804; sign, originally from Nepal, the land of himalayas &#9968; .I am currently pursuing my Master's degree at **Grand Valley State University**. I am in second year of Data Science and Analytics program. My undergradute is in Information Management. I have worked in couple of companies as Front-end Web designer and User Interface Designer for Android Application. 

Currently I work as a Graduate Assistant at **Grand Valley Charter School Office** as a Research and Data Analyst. Some of the work that I do are,
- _Data Collection_, 
- _Analysis the data_, 
- _Evaluate the data and generate the reports_ 

Comming from IT background, I have worked on different companies which are listed below:

|`Company Name`                  |`Position`                         |`Job Description`                             |
| ------------------------------ | --------------------------------- | --------------------------------------------|
|1. AB Group Pvt ltd             |Front End Designer                 | Monitered and ensured Advertisements|
|2. NIRC Pvt. Ltd                |Front-End and Graphics Designer    | Created Websites and Videos Using Bootstrap and Premeire|
|3. Cool Tool Dig. Media Pvt. Ltd|User Interface Designer            | Designed and Customized Websites and Applications|
|4. Grand Valley State University|Graduate Research Assistant        | Prepare materials for the undergraduate course in **Network                                                                           Analysis and Graph Theory** for course 310|  













