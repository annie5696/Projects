---
title: "Application Task 2"
author: "Anisha Shrestha"
date: "10/11/2019"
output: 
  html_document: 
    keep_md: yes
---

### Load packages


```r
library(tidyverse)
library(dplyr)
library(tidyr)
library(ggplot2)
library(mosaic)
```

### Load data


```r
pokemon <- read_csv("data/pokemon.csv")
```


### 2.1: How do Pokémon heights change after evolution?


```r
#Percentage of Pokémon that grew during evolution
total_count= nrow(pokemon)
pokemon %>%
  mutate(diff_height=pokemon$height_new - pokemon$height) -> pokemon_sample 
#Difference in Height stored as diff_height in pokemon_sample
head(pokemon_sample$diff_height)
```

```
## [1] 0.90 0.76 0.81 0.81 0.71 0.92
```

```r
pokemon_sample %>%
        group_by(species, diff_height) %>%
        tally()-> dat1
percent_height_count<- sum(dat1$n)
percent_evolved <- total_count/ percent_height_count*100  # total count of percent height divided by total number of species changed
percent_evolved
```

```
## [1] 100
```
**All the pokemon's height has changed which bring to 100 percent.**


```r
#Boxplot for change in height by species
ggplot(pokemon_sample, aes(x = species, y = diff_height, fill = species)) + geom_boxplot() +
facet_wrap( ~ species, ncol=4,scales = "free_x")+ labs(title = "BoxPlot with Difference in Height and Facetted by Species", x = "Species", y = "percent Height")+theme_minimal() +scale_fill_discrete(name = "SPECIES") + theme( text=element_text(size=11.5, family="Arial light"))
```

![](application02_files/figure-html/unnamed-chunk-2-1.png)<!-- -->


**The Box plot above shows the difference of height that changed. Form the graphs, it shows there is a lot of change in Pidgey species., followed by Eevee species which has outlier and Weedle at the last. We substract the new height by old height., which gives the values for the box plot. The results shows that there is a rapid increment in height of Pidgey and very less increase in Weedle species of pokemon that grew during evolution.**



```r
#Lets look at the Old height in general species. 
ggplot(pokemon, aes(x = species, y = height, fill = species)) + geom_boxplot() +
facet_wrap( ~ species, ncol=4,scales = "free_x")+ labs(title = "BoxPlot of Pokemon data with Old Height by Species", x = "Species", y = "Old Height")+theme_minimal() +scale_fill_discrete(name = "SPECIES") + theme( text=element_text(size=11.5, family="Arial light"))
```

![](application02_files/figure-html/unnamed-chunk-3-1.png)<!-- -->

**The above Box plot above shows the old height and the species. There is not much difference in median between the species. The reults shows that there is an outlier in the weedle species where as small differences in the quartile range.**

### 2.2: Recreate this plot 
### Pre-evolution weaker attack of the pokemon by species


```r
pokemon %>%
group_by(species,attack_weak) %>% 
tally() %>%
arrange(species, attack_weak,  desc(n)) %>%
spread(key = species, value=n) -> pokemon_go
df = subset(pokemon_go, select = -c(Weedle))
df1 <- df %>% slice(-2) #helps to get ride of second row
data <- df1 %>% gather(species, frequency, Caterpie:Pidgey)
Final_data <- na.omit(data)%>%
group_by(species)
ggplot(data = Final_data, aes(x = species, y = frequency, fill = attack_weak))+ geom_col(position = position_dodge()) +coord_flip()+ labs(title = "Pre-evolution weaker attack of the Pokémon", subtitle = "by species", x = "Species", y = "Frequency")+theme_minimal() +scale_fill_discrete(name = "Attack Weak") + theme(panel.border = element_blank(), text=element_text(size=11.5, family="Arial light"))
```

![](application02_files/figure-html/unnamed-chunk-4-1.png)<!-- -->


### 2.3: Do Pokémon tend to change their stronger attack post-evolution?

**The code below calculating the relative frequency for post-evolution stronger attack based on the pre-evolution stronger attack for each rows.**


```r
#creating a Table using DPLYR and calculating Relative frequency
pokemon %>% group_by(attack_strong,attack_strong_new) %>% summarise(n = n()) %>%
  spread(key = attack_strong, value = n, fill = 0) -> table_a
table_a[c(2:8), c(2:8)] <- sapply(table_a[c(2:8), c(2:8)], as.numeric)
sum_row <- rowSums(table_a[,2:8] )
mutate(table_a, sum_row)
```

```
## # A tibble: 8 x 9
##   attack_strong_n… `Aerial Ace` `Air Cutter` `Body Slam`   Dig Struggle
##   <chr>                   <dbl>        <dbl>       <dbl> <dbl>    <dbl>
## 1 Aerial Ace                  4            5           0     0        0
## 2 Air Cutter                  4            5           0     0        0
## 3 Aqua Tail                   0            0           1     0        0
## 4 Fire Blast                  0            0           0     1        0
## 5 Heat Wave                   0            0           2     0        0
## 6 Struggle                    0            0           0     0       30
## 7 Thunderbolt                 0            0           0     1        0
## 8 Twister                     3            3           0     0        0
## # … with 3 more variables: Swift <dbl>, Twister <dbl>, sum_row <dbl>
```

```r
pro_table <- ((table_a[, 2:8])/ sum_row)
pro_table
```

```
##   Aerial Ace Air Cutter Body Slam Dig Struggle Swift   Twister
## 1  0.2500000  0.3125000       0.0   0        0   0.0 0.4375000
## 2  0.3076923  0.3846154       0.0   0        0   0.0 0.3076923
## 3  0.0000000  0.0000000       0.5   0        0   0.5 0.0000000
## 4  0.0000000  0.0000000       0.0   1        0   0.0 0.0000000
## 5  0.0000000  0.0000000       1.0   0        0   0.0 0.0000000
## 6  0.0000000  0.0000000       0.0   0        1   0.0 0.0000000
## 7  0.0000000  0.0000000       0.0   1        0   0.0 0.0000000
## 8  0.3000000  0.3000000       0.0   0        0   0.0 0.4000000
```

**The table is created for attak_strong_new and attack_strong. Thus We calculate the relative frequency which is shown by the table above**


**The code below directly calculating the propotional frequencies of post-evolution stronger attack based on the pre-evolution stronger attack. We group by `attack_strong_new`, `attack_strong` and `n` as their frequencies. The table below shows the propotional frequencies for `attack_strong_new` with respect to matching count with `attack_strong`.**

##### Directly Calculating without making any tables similar to above code


```r
library(magrittr)
```

```
## 
## Attaching package: 'magrittr'
```

```
## The following object is masked from 'package:purrr':
## 
##     set_names
```

```
## The following object is masked from 'package:tidyr':
## 
##     extract
```

```r
pokemon %>%
  dplyr::group_by(attack_strong_new, attack_strong) %>%
  dplyr::summarise(n = n()) %>%
  mutate(prop.frequency = n / sum(n))
```

```
## # A tibble: 15 x 4
## # Groups:   attack_strong_new [8]
##    attack_strong_new attack_strong     n prop.frequency
##    <chr>             <chr>         <int>          <dbl>
##  1 Aerial Ace        Aerial Ace        4          0.25 
##  2 Aerial Ace        Air Cutter        5          0.312
##  3 Aerial Ace        Twister           7          0.438
##  4 Air Cutter        Aerial Ace        4          0.308
##  5 Air Cutter        Air Cutter        5          0.385
##  6 Air Cutter        Twister           4          0.308
##  7 Aqua Tail         Body Slam         1          0.5  
##  8 Aqua Tail         Swift             1          0.5  
##  9 Fire Blast        Dig               1          1    
## 10 Heat Wave         Body Slam         2          1    
## 11 Struggle          Struggle         30          1    
## 12 Thunderbolt       Dig               1          1    
## 13 Twister           Aerial Ace        3          0.3  
## 14 Twister           Air Cutter        3          0.3  
## 15 Twister           Twister           4          0.4
```


### 2.4: Relationship between categorical variables


```r
ggplot(pokemon, aes(species, ..count..)) + geom_bar(aes(fill = attack_weak_new), position = "dodge")+theme(text=element_text(size=14, family="Calibri"))+labs(title = "Bar plot for two Categorical Variables:", subtitle = "by Species and Attack Weak New", x = "Species", y = "Frequency") + scale_fill_discrete(name = "Attack Weak New")+ coord_flip()
```

![](application02_files/figure-html/unnamed-chunk-7-1.png)<!-- -->

**On this bar chart, two categorical variables that are, Species and Attack Weak New which shows there under pidgey, we have high count for attack weak i.e Steel Wing. In contrast, the lowest attack weak new value is under Eevee's Thunder Shock.**

### 2.5: Comparative boxplots


```r
ggplot(pokemon, aes(x = as.factor(species), y = power_up_stardust)) + geom_boxplot(outlier.colour = "red", outlier.shape = 0.5)+labs(title = "Box Plot", subtitle = "Power Up Stardust and Species", x = "Species", y = "Power Up Stardust") +theme(text=element_text(size=14, family="Times New Roman"))+aes(colour = species) + theme(plot.title = element_text(hjust = 0.5), plot.subtitle = element_text(hjust = 0.5,face = "italic")) +coord_flip()
```

![](application02_files/figure-html/unnamed-chunk-8-1.png)<!-- -->


**The above given figure is the Box plot of numerical and categorical variables. The variables chosen are Species as categorical and power up stardust as a numerical variable for the plot. As we can see the Eevee's median value is the cutoff value here due to very high outlier which is around 3000 points in power_up_stardust. The Caterpie box is approx. equally skewed and also Caterpie and Weedle have almost same median value but have different percentiles range. Pidgey is right skewed where the median value is higher than the mean value. We have records from the above figure, the pidgey have the largest value with a high relative frequency.**



### 2.6: Violin plots

```r
ggplot(pokemon, aes(x=species, y=power_up_stardust, fill=species)) + geom_violin(trim=FALSE)+ggtitle("Violin Plot for Species and Power_up_Stardust")+scale_color_brewer(palette="Dark2")+labs(title = "Violin Plot", subtitle = "Species and Power Up Stardust", x = "Species", y = "Power Up Stardust")+ theme_bw()+theme(plot.title = element_text(color = "SaddleBrown", size = 20, face = "bold")) + scale_fill_discrete(name = "SPECIES")
```

![](application02_files/figure-html/unnamed-chunk-9-1.png)<!-- -->



#### What do the violin plots reveal that the boxplots do not? What features are apparent in the boxplots, but not in the violin plots?
_Ans:_ **A violin plot is a hybrid of a box plot , which shows peaks in the data. The shape of the distribution (extremely skinny on each end and wide in the middle) indicates the power_up_stardust of pokemon are highly concentrated around the median. Box plot sometimes can be misleading in terms of displaying the data, as their visual simplicity tends to hide significant details about how the values in the data are distributed whereas Violin plots displays more information, the thicker part means the values in that section of the violin has higher frequencies and the thinner part means lower.**
**In the box plot, they actually shows medians, ranges and variabilities effectively. Box plots helps in comparaision of different group, summary statistics and also they are very simple and easy to understand.**
**As we can see, Eevee has very few number/density and also has the outlier. Thus, the violin plot tends to go upward towards 3000 power_up_stardust. Similarly, other species like Caterpie, Pidgey, Weedle shows how the density of the data are destributed making that particular section thicker and vice-versa.**


### 2.7: Characteristics of an evolved Pokémon combat power.



```r
pokemon %>%
dplyr::group_by(species,cp,height, cp_new, height_new,attack_strong_value, attack_strong_value_new ) %>% 
#comparision between new and old pokemon's height, attack Value and combat power
dplyr::summarise(n = n()) ->pokemon_data
head(pokemon_data)             #gives top 6 values
```

```
## # A tibble: 6 x 8
## # Groups:   species, cp, height, cp_new, height_new, attack_strong_value
## #   [6]
##   species    cp height cp_new height_new attack_strong_v… attack_strong_v…
##   <chr>   <dbl>  <dbl>  <dbl>      <dbl>            <dbl>            <dbl>
## 1 Caterp…    10  0.290     10      0.69                15               15
## 2 Caterp…    43  0.28      46      0.65                15               15
## 3 Caterp…    86  0.3       92      0.7                 15               15
## 4 Caterp…   128  0.24     137      0.570               15               15
## 5 Caterp…   136  0.35     150      0.82                15               15
## 6 Caterp…   140  0.3      151      0.71                15               15
## # … with 1 more variable: n <int>
```

```r
#arranges the data into decending orer based on new combat power
data1<- arrange(pokemon_data, desc(cp_new))
head(data1)
```

```
## # A tibble: 6 x 8
## # Groups:   species, cp, height, cp_new, height_new, attack_strong_value
## #   [6]
##   species    cp height cp_new height_new attack_strong_v… attack_strong_v…
##   <chr>   <dbl>  <dbl>  <dbl>      <dbl>            <dbl>            <dbl>
## 1 Eevee     619  0.2     1646       0.68               40               45
## 2 Eevee     606  0.38    1591       1.26               30               45
## 3 Eevee     548  0.32    1362       0.95               40               80
## 4 Eevee     517  0.290   1340       0.88               40               80
## 5 Eevee     500  0.26    1253       0.77               70              100
## 6 Eevee     528  0.31    1059       0.82               70               55
## # … with 1 more variable: n <int>
```



**From this summary we can see that the combat power has increases tremendously in the cp_new. We can also visualize this using various plots based on the species to see which species has increased during that time.  The table on top shows the species and its corresponding values. The species with a highest combat power is Eevee which also has the stronger attack value.** 




```r
ggplot(data1, aes(x = as.factor(species), y = attack_strong_value)) + geom_boxplot(outlier.colour = "red", outlier.shape = 0.5)+labs(title = "Box Plot", subtitle = "Attack Strong Value and Species", x = "Species", y = "Attack Strong Value") +theme(text=element_text(size=14, family="Times New Roman"))+aes(colour = species) + theme(plot.title = element_text(hjust = 0.5), plot.subtitle = element_text(hjust = 0.5,face = "italic"))
```

![](application02_files/figure-html/unnamed-chunk-11-1.png)<!-- -->



**This shows the attack strong value with species, where `Eevee` has the highest range among all three. and `caterpie` and `Weedle` being the lowest, from the summary table.**




```r
ggplot(data1, aes(x=cp, y=cp_new, color=species, shape=species)) +
  geom_point()+labs(title = "Scatter Plots", subtitle = "Combat Power and New Combat Power", x = "combat Power", y = "New Combat Power") + theme(text=element_text(size=12, family="arial"))+aes(colour = species) + theme(plot.title = element_text(hjust = 0.5), plot.subtitle = element_text(hjust = 0.5,face = "italic"))
```

![](application02_files/figure-html/unnamed-chunk-12-1.png)<!-- -->


**From the scatter plot, we can see that there is a very high increase in the `Eevee species` like before  which has increased sharply.**



```r
ggplot(data1, aes(x=height, y=height_new, color=species, shape=species)) +
geom_point() +labs(title = "Scatter Plots based on Old and New height", x = "Old Height", y = "New Height") + theme(text=element_text(size=12, family="arial"))+aes(colour = species)
```

![](application02_files/figure-html/unnamed-chunk-13-1.png)<!-- -->



**In the last figure the scatter plot for old and New height shows, there is high increasement in the `Pigdey` and `Eevee` species whereas Weedle being the lowest one. from this we can conclude that, `Eevee` has much variability but has the most highest Combact Power then any other pokemon and holds a higher stronger attack value as well. Similary, the range of height percentage increasement is more on Eevee but the most growth change is seen on Weedle compared to all other species.**


















