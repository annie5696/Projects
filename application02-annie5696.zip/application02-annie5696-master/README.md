# Application02

**1.** A **repository** is like a folder where we can store  all the files, projects and can track the history of the file. We can discuss and manage our project's work by owner or whoever has the access to the repository by simply sharing ownership of repositories with other people in an organization. 

   + I first collaborated on repo name by accepting the invitation  [**application02-annie5696**](https://github.com/sta518/application02-annie5696)  
   + On the first Landing pages of the repo, we can see the primary repo name on left top or in the URL after "/" ([github.com/**sta518**](https://github.com/sta518)), which has collection of all other reposiory. Under this, my repo is ([github.com/sta518/**application02-annie5696**](https://github.com/sta518/application02-annie5696))
   + Under this file, options like how many commit, branch and who have the access to this repo ( _contributer's information_) are stored on top of the table. Below the orange line, informations like upload, finding any files, clone etc are available. The following process can be accessed through this repo which are explained below.
   
   |`Name`                          |`Description`                             |
| ------------------------------ | --------------------------------------------|
|1. [**application02.Rmd**](https://github.com/sta518/application02-annie5696/blob/master/application02.Rmd) | We can see the embedded R code chunks that can be run, and allows output to be included in the document.|
|2. [application02-annie02/**application02_md**](https://github.com/sta518/application02-annie5696/blob/master/application02.md) | Append the results of the code to the document next to the code chunk.|
|3. [**README.html**](https://github.com/sta518/application02-annie5696/blob/master/README.html)                | Self build html file, which automatically generates html code whatever we type in `.Rmd file`|
|4. [**README.md**](https://github.com/sta518/application02-annie5696/blob/master/README.md) | I have written all this information.|
|5. [**application02.html**](https://github.com/sta518/application02-annie5696/blob/master/application02-instructions.html) | similar to `README.html`. |
|6. [**application02-instructions.md**](https://github.com/sta518/application02-annie5696/blob/master/application02-instructions.md) | Information of the workflow|
|7. [application02-annie02/**application02-instructions.html**](https://github.com/sta518/application02-annie5696/blob/master/application02-instructions.html) | This is the html file automatically generated html code|
|8. [application02-annie02/**application02_files/figure-html**](https://github.com/sta518/application02-annie5696/tree/master/application02_files/figure-html) | This holds all the images and graphics in the `rmd` file.|







        