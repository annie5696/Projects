---
title: Application Task 2

---

## The Workflow

Due by 11:59 pm Sunday, Sept. 22nd.

### Overview
The goal of these tasks are to explore a dataset within RStudio.
You will use `dplyr` and `ggplot2` to describe and visualize the dataset.
If you run into any issues, we should be able to get them worked out.

You will be submitting three items: [1] a README.md and [2] an R Markdown report through GitHub, and [3] a reflection on Bb.

#### Evaluation

Tasks 1 and 3 will be evaluated using the [Meeting Preparation Grading Standards](https://sta518.github.io/syllabus/assessment/#meeting-preparation-1).
Each subtask in Task 2 will each be evaluated using the [Application Tasks Grading Standards](https://sta518.github.io/syllabus/assessment/#application-tasks-1).

Your overall Application Task 1 grade will be based on the following criteria:

- Excellent (**E**): Each task earned an Excellent of Satisfactory, including one Excellent.
- Satisfactory (**S**): Each task earned a Satisfactory.
- Progressing (**P**): Each task earned a Satisfactory or Progressing.
- Incomplete (**I**): At least one task earn an Incomplete or was not submit.

### Create Your `application02` Repo

GitHub Classroom will automatically make a repository for you, called `application02-your_github_username`, for you to work on your assignment.
Follow these instructions to get the repo:

1. Sign-in to [Bb](https://mybb.gvsu.edu)
2. Go to the **Application Task 2** assignment page.

Here, you will find a url leading to a page on GitHub Classroom.
Visit this page and follow the instructions.
When you obtain your repository, it should contain a copy of this `application02-instructions.md` file, a blank `README.md` file, and a starter `application02-exploration.Rmd` file.

#### 1. Edit `README.md` 

Your task here is to edit the `README.md` file in your repository to contain a sample of GitHub-flavored markdown features.
Specifically, your README should contain a brief description as to what the repo is, so that an unknown visitor landing on the repo can orient themselves
You should also help the visitor navigate your repository (in whatever way you think is most appropriate).

Remember the resources you were directed to view during your work in the class activities and Meeting Preparations.
These are also organized in the [Additional Resources/Markdown](https://sta518.github.io/resources/markdown/) section of this site.

You can edit the README in your browser like we did in class, but I encourage you to experiment with editing it from within RStudio.
**FYI, this will be a private repo - only you and I will be able to see it.**

#### 2. Exploration with R Markdown

This task explores a dataset, similarly to what we did in-class with.
Edit the R Markdown document and your final submission should include both text and code intertwined.
If you simply complete the subtasks, this would be considered *sufficient*.
Effectively adding your own creative twist, without being distracting from the subtasks, would be considered *excellent*.

You will be using data collected from [Pokémon Go](https://www.pokemongo.com/en-us/).
A key part of Pokémon Go is using evolutions to get stronger Pokémon.
Understanding these evolutions is key to being the greatest Pokémon Go player of all time.
This data is from the [OpenIntro Statistics](https://www.openintro.org/index.php) series by David Diez, Mine Çetinkaya-Rundel, and Christopher Barr.

Knit your completed `.Rmd` file and commit both your `.Rmd` file and the `.md` that is automatically created push them to GitHub.

##### Data

The data set you will be working with for this assignment covers 75 Pokémon evolutions spread across four species.
A wide set of variables are provided, allowing a deeper dive into what characteristics are important in predicting a Pokémon's final combat power (CP).

For each subtask, include an interpretation of your output (and what it reveals about the data).
The [codebook](https://www.openintro.org/stat/data/?data=pokemon) will be a useful tool to learn more about the variables included in this dataset and what they represent.

##### 2.1: How do Pokémon heights change after evolution?

Calculate the difference in heights pre and post evolution and save this as a new variable in the dataset.
Calculate the percentage of Pokémon that grew during evolution.
Also, visualize the distribution of change in height by species.
Provide a discussion of how change in height varies both in general and across species.

##### 2.2: Recreate this plot 

I forgot to save the code that produced the following plot.
Use your `dplyr` and `ggplot2` skills to recreate it.

![lost code plot](img/recreate-application02.png)

##### 2.3: Do Pokémon tend to change their stronger attack post-evolution?

Calculate the relative frequency of post-evolution stronger attack based on the pre-evolution stronger attack.
Provide a discussion.

##### 2.4: Relationship between categorical variables

Pick two categorical variables and construct a plot (bar plot or another appropriate choice) that depicts the relationship between them.
These variables can be from the original data or ones that you create based on the given data.
Provide a discussion.

##### 2.5: Comparative boxplots

Pick a numerical and a categorical variable and construct a side-by-side boxplot depicting their relationship.
Provide a discussion.

##### 2.6: Violin plots

Read about violin plots at [https://ggplot2.tidyverse.org/reference/geom_violin.html](https://ggplot2.tidyverse.org/reference/geom_violin.html).
Using the same numerical and categorical variables from Task 2.5, construct violin plots.
What do the violin plots reveal that the boxplots do not?
What features are apparent in the boxplots, but not in the violin plots?

##### 2.7: Characteristics of an evolved Pokémon combat power

What characteristics correspond to an evolved Pokémon with a high combat power?
You do not need to come up with an exhaustive list, but you should walk through your reasoning as you answer this question.
Include all relevant summary statistics and visualizations.

#### 3. Reflection
  
After you have completed Tasks 1 and 2 go back to the **Application Task 2** assignment page on [Bb](https://mybb.gvsu.edu).
You will submit your reflection here that minimally includes:

- A clickable link to your Application Task 2 repository.
- A reflection on what was hard/easy, problems you came across and how you solved them, helpful tutorials you read, etc.