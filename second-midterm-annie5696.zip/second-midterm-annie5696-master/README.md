# second-midterm

This repo contains the following information about the Second Midterm:

1. [Second Midterm Repo](https://github.com/sta518/second-midterm-annie5696)

2. [Instructions](https://github.com/sta518/second-midterm-annie5696/blob/master/second-midterm-instructions.md)

3. [R Markdown Document](https://github.com/sta518/second-midterm-annie5696/blob/master/second-midterm.Rmd)

4. [Data](https://github.com/sta518/second-midterm-annie5696/tree/master/data)

5. [md file Second Midterm](https://github.com/sta518/second-midterm-annie5696/blob/master/second-midterm.md)

7. [This readme file](https://github.com/sta518/second-midterm-annie5696/blob/master/README.md)



> The second mentioned contains the real datasets for Allendale student where there are 200 number of observations. We are basically exploring the data by creating a linear model and finding the best fitted models. What are the patterns of the datasets and how are they connected to each other.
