---
title: "Application Task 3"
author: "Anisha shrestha"
date: "oct 18-2019"
output: 
  html_document: 
    keep_md: yes
---

##### Load packages


```r
library(tidyverse)
library(infer)
library(mosaic)
library(plyr)
library(data.table)
```

##### Load data


```r
gss_sample <- read_csv("data/gss2016.csv")

gss <- read_csv("data/gss2016.csv",
                na = c("", "Don't know",
                       "No answer", "Not applicable"),
                guess_max = 2867) %>%
  select(harass5, emailmin, emailhr, educ, born, polviews, advfront)
```

##### Set seed


```r
set.seed(1020)
```

#### 2.1: Harrassment at work

#### What are the possible responses to this question and how many respondents chose each of these answers?


```r
 gss%>%
  group_by(harass5) %>% 
  tally()
```

```
## # A tibble: 4 x 2
##   harass5                                                     n
##   <chr>                                                   <int>
## 1 Does not apply (i do not have a job/superior/co-worker)    96
## 2 No                                                       1136
## 3 Yes                                                       237
## 4 <NA>                                                     1398
```

**The Possible responses for the question was column `harass5` where 237 people answered YES and 1136 people answered NO. Similarly, 96 told they don't have a job or superior and remaining 1398 choose not to answer.  **


#### Extract the column YES and NO from the dataframe and exporting it to different data frame `gss_yes_no`


```r
gss_yes_no <- gss %>%
  filter(harass5 %in% c("Yes", "No"))
(gss_yes_no)
```

```
## # A tibble: 1,373 x 7
##    harass5 emailmin emailhr  educ born  polviews             advfront
##    <chr>      <dbl>   <dbl> <dbl> <chr> <chr>                <chr>   
##  1 No            NA      NA    16 Yes   Conservative         <NA>    
##  2 No            NA      NA    18 Yes   Slightly liberal     <NA>    
##  3 No            NA      NA    11 No    Slghtly conservative <NA>    
##  4 No            NA      NA    14 Yes   Conservative         <NA>    
##  5 No             0       2    12 Yes   <NA>                 <NA>    
##  6 Yes           NA      NA    13 Yes   Moderate             <NA>    
##  7 No            NA      NA    13 No    Conservative         <NA>    
##  8 No             0       1    18 Yes   Liberal              <NA>    
##  9 No            NA      NA    11 Yes   Slghtly conservative <NA>    
## 10 No             0       1    10 No    Slightly liberal     <NA>    
## # … with 1,363 more rows
```

**The new data frame here is `gss_yes_no`. **

#### What percent of the respondents who answereed "Yes" or "No" to this question have been harassed by their superiors or co-workers at their job?


```r
#summary table or yes and no Only
gss_yes_no %>%
  dplyr::group_by(harass5) %>%
  dplyr::summarise(n = n()) %>%
  mutate(freq = n / sum(n))
```

```
## # A tibble: 2 x 3
##   harass5     n  freq
##   <chr>   <int> <dbl>
## 1 No       1136 0.827
## 2 Yes       237 0.173
```

**The people who said YES has 17.26 percentage and for NO 82.74 percentages in total were harrassed.**

##### Construct and visualize a bootstrap distribution for the proportion of Americans who have been harrassed at work. Use this general form as a recipe:


```r
variable_ci_statistic <- gss_yes_no %>%
  specify(response = harass5, success="Yes") %>% # specify(response= pov_new varibale, sucess="Liberal")
  generate(reps = 1000, type = "bootstrap") %>% 
  calculate(stat = "prop")

#making the histogram plot for americans who were harassed
ggplot(data = variable_ci_statistic, aes(x = stat)) +geom_histogram(color="Chocolate",fill="peachpuff")+ labs(title = "Histogram plot using Bootstrap distrubution", subtitle = "americans who were harressed", y = "Count")+theme_minimal()->p
CI <- ddply(variable_ci_statistic, .(stat),
              summarize, q=quantile(variable_ci_statistic$stat, c(.025, .975)))
q #95 percent Confidence Interval
```

```
## function (save = "default", status = 0, runLast = TRUE) 
## .Internal(quit(save, status, runLast))
## <bytecode: 0x8de8a80>
## <environment: namespace:base>
```

```r
p + geom_vline(aes(xintercept=q), data=CI, color="black", linetype="dashed") + geom_density(fill = 'pink', alpha=0.3)
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

![](application03_files/figure-html/unnamed-chunk-4-1.png)<!-- -->



**In the above table, we have 1000 replicates, and also added seed to reproduce different random variables. Form the above quantile range, I am 95% confident that the portion of Americans who has been harrssed falls within the range of 15.14% to 19.98.(round aboout) **


#### 2016 GSS was how many years of schooling they completed?


```r
ggplot(data = gss, mapping = aes(x = educ)) +
  geom_histogram(binwidth = 1, fill = "white", color = "black") +
  theme_minimal()
```

```
## Warning: Removed 9 rows containing non-finite values (stat_bin).
```

![](application03_files/figure-html/unnamed-chunk-5-1.png)<!-- -->


```r
gss %>%
  dplyr::group_by(born) %>%
  dplyr::summarise(n = n()) 
```

```
## # A tibble: 3 x 2
##   born      n
##   <chr> <int>
## 1 No      355
## 2 Yes    2507
## 3 <NA>      5
```



```r
gss %>%
  dplyr::group_by(educ) %>%
  dplyr::summarise(n = n()) 
```

```
## # A tibble: 22 x 2
##     educ     n
##    <dbl> <int>
##  1     0     2
##  2     1     3
##  3     2     3
##  4     3     3
##  5     4     2
##  6     5     4
##  7     6    31
##  8     7    18
##  9     8    48
## 10     9    59
## # … with 12 more rows
```



```r
gss_educ <- gss %>%
  filter(
    !is.na(educ),
    !is.na(born)
  )
```



```r
diff_educ_born_boot <- gss_educ %>%
  specify(response = educ, explanatory = born) %>%
  generate(reps = 1000, type = "bootstrap") %>%
  calculate(stat = "diff in means", order = c("Yes", "No"))
```

**The response variables here is education and we split born with Yes and No only. We can see how it shows differences in mean number of people's education who was born in US and not born in US.**


##### Take a bootstrap sample of those born in the US and a bootstrap sample of those not born in the US. These are random samples, taken with replacement, from the original samples, of the same size as the original samples.



```r
diff_educ_born_boot <- gss_educ %>%
  specify(response = educ, explanatory = born) %>%
  generate(reps = 1000, type = "bootstrap") %>%
  calculate(stat = "diff in means", order = c("Yes", "No"))
```



#### 2.2: Liberals vs. Conservatives - Is science research necessary?

####1.  Mutate a new variable, i.e., recode advfront, such that "Strongly agree" and "Agree" are mapped to "Yes", and "Disagree" and "Strongly disagree" are mapped to "No". The remaining levels can be left as is.


```r
gss %>% mutate(advfront_new=case_when
               ((advfront == "Strongly agree") | (advfront == "Agree") ~ "Yes",
                 (advfront == "Disagree") | (advfront == "Strongly disagree") ~ 'No',
                 TRUE ~ advfront
                 ))-> gss
```


**The new variable created here is `advfront_new`, where Strongly Agree and Agree are converted to Yes and Disagree and Strongly disagree are mapped to "No". The remaining levels are left as is.**




##### 2.. Mutate a new variable, i.e., recode polviews, such that "Extremely liberal", "Liberal", and "Slightly liberal", are mapped to "Liberal", and "Slghtly conservative", "Conservative", and "Extrmly conservative" are mapped to "Conservative". The remaining levels can be left as is.


```r
gss %>%  mutate(polviews_new = case_when(
  polviews %in% c("Extremely liberal", "Liberal","Slightly liberal") ~ "Liberal",
  polviews %in% c("Slghtly conservative", "Conservative", "Extrmly conservative") ~ "Conservative",
  TRUE ~ polviews
))->gss
```

**The new variable created here is `polviews_new`, where Extremly liberal, liberal, slightly liberal are converted to Liberal and Slightly conservative, Conservative, Extremly conservative are mapped to "Conservative". The remaining levels are left as is.**


#### 3.Filter the data for respondents who self-identified as "liberal" or "conservative" and who responded "yes" or "no" to the science research question. Save the resulting data frame with a different name so that you don't overwrite the data.

> filtering data


```r
gss %>%  filter(polviews_new %in% c("Liberal","Conservative") & (advfront_new %in% c('Yes','No')))->filtered_new
filtered_new
```

```
## # A tibble: 807 x 9
##    harass5 emailmin emailhr  educ born  polviews advfront advfront_new
##    <chr>      <dbl>   <dbl> <dbl> <chr> <chr>    <chr>    <chr>       
##  1 <NA>          30       0    12 Yes   Liberal  Disagree No          
##  2 <NA>           0       2    14 No    Slightl… Strongl… Yes         
##  3 <NA>           0      40    14 No    Slightl… Strongl… Yes         
##  4 <NA>           0      10    12 Yes   Slightl… Agree    Yes         
##  5 <NA>           0       1    10 Yes   Slightl… Agree    Yes         
##  6 <NA>           0       2    13 Yes   Liberal  Agree    Yes         
##  7 <NA>           0      25    12 Yes   Liberal  Strongl… Yes         
##  8 <NA>          NA      NA    19 Yes   Liberal  Agree    Yes         
##  9 <NA>           0       1    12 Yes   Liberal  Strongl… Yes         
## 10 <NA>           0       2    12 Yes   Slghtly… Strongl… Yes         
## # … with 797 more rows, and 1 more variable: polviews_new <chr>
```

**The new data frame is filtered_new where we only choose responded yes or no to the science research and identified as liberal and conservative.**



#### 4. Describe how you will use bootstrapping to estimate the difference in proportion of liberals and not liberals who think science research is necessary and should be supported by the federal government.


```r
difference <- 
  filtered_new %>% 
  specify(response = advfront_new, explanatory=polviews_new, success='Yes') %>%
  generate(reps = 1000, type = "bootstrap") %>%
  calculate(stat = "diff in props", order = c("Liberal","Conservative"))
```

**First, filtered out the advfront_new for only Yes and specify our response variable to be polviews_new and success is Liberal. As we generate samples using bootstrap. We calculate the proportion of liberals and not liberals who think science research is necessary and should be supported by the federal government.**



#### 5. Construct a 90% bootstrap confidence interval for the difference in proportion of liberals and conservatives who think science research is necessary and should be supported by the federal government. Interpret this interval in context of the data.



```r
#making the histogram plot for Differences of proportion of liberals and conservatives
quantile(difference$stat, prob=c(0.10,0.90)) #90 percentage CI 
```

```
##        10%        90% 
## 0.04773443 0.11092796
```

```r
ggplot(difference, aes(x=stat)) + geom_histogram(aes(y=..density..), bins=30, color='Chocolate', fill='peachpuff') + geom_density(alpha=.4, fill="yellow") + labs(title = "Differences of proportion of liberals and conservatives who thinks science research is necessary", subtitle = "proportion of liberals and conservatives", y = "Density") +geom_vline(aes(xintercept=0.0475333),linetype="dashed", size=1, colour="blue") + geom_vline(aes(xintercept=0.11029454 ),linetype="dashed", size=1, colour="blue")+theme_minimal()
```

![](application03_files/figure-html/unnamed-chunk-15-1.png)<!-- -->


**I am 90% confident that the proportion of liberals and conservatives who think science research is necessary and should be supported by the federal government falls with in the range of 0.047 % to 11.029% .**

**Easy construction of the 90% CI from the resampling distribution.The x and y intercepts captures the 90% of the distribution in the graphs. We put diff in prop in calculate function and thus put libreal and conservative in our order functions. Such an interval construction is known as a percentile interval. Firstly, specifying our response variable to be advfront_new and success is Yes meaning who think science research is necessary and should be supported by the federal government.**


