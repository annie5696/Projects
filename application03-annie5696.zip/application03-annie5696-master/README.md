# Application03

**1.** A **repository** is like a folder where we can store  all the files, projects and can track the history of the file. Application 3 deals with the data collected from the General Social Survey (GSS) on contemporary American society in order to monitor and explain trends and constants in attitudes, behaviors, and attributes. In this application task we analyze data from the 2016 GSS, using it to estimate values of population parameters of intertest about US adults.. 

   + I first collaborated on repo name by accepting the invitation  [**application03-annie5696**](https://github.com/sta518/application03-annie5696)  
   + On the first Landing pages of the repo, we can see the primary repo name on left top or in the URL after "/" ([github.com/**sta518**](https://github.com/sta518)), which has collection of all other reposiory. Under this, my repo is ([github.com/sta518/**application03-annie5696**](https://github.com/sta518/application03-annie5696))
   + Under this file, options like how many commit, branch and who have the access to this repo ( _contributer's information_) are stored on top of the table. Below the orange line, informations like upload, finding any files, clone etc are available. The following process can be accessed through this repo which are explained below.
   
   |`Name`                          |`Description`                             |
| ------------------------------ | --------------------------------------------|
|1. [**application03.Rmd**](https://github.com/sta518/application03-annie5696/blob/master/application03.Rmd) | We can see the embedded R code chunks that can be run, and allows output to be included in the document.|
|2. [application03-annie5696/**application03.md**](https://github.com/sta518/application03-annie5696/blob/master/application03.md) | Append the results of the code to the document next to the code chunk.|
|3. [**README.html**](https://github.com/sta518/application03-annie5696/blob/master/README.html)                | Self build html file, which automatically generates html code whatever we type in `.Rmd file`|
|4. [**README.md**](https://github.com/sta518/application03-annie5696/blob/master/README.md) | I have written all this information.|
|5. [**application03.html**](https://github.com/sta518/application03-annie5696/blob/master/application03.html) | similar to `README.html`. |
|6. [**application03-instructions.md**](https://github.com/sta518/application03-annie5696/blob/master/application03-instructions.md) | Information of the workflow|
|7. [application03-annie5696/**application03_files/figure-html**](https://github.com/sta518/application03-annie5696/tree/master/application03_files/figure-html) | This holds all the images and graphics in the `rmd` file.|