---
title: "Application Task 3"
author: ""
date: ""
output: 
  html_document: 
    keep_md: yes
---



## The Workflow

Due by 11:59 pm Sunday, Oct. 10th.

### Overview
The goal of these tasks are to explore a dataset within RStudio.
You will use `infer` package to do statistical inference using the bootstrap alogrithm along with `dplyr` and `ggplot2` packages to describe and visualize the dataset.
If you run into any issues, we should be able to get them worked out.

You will be submitting three items: [1] a README.md and [2] a report through GitHub, and [3] a reflection on Bb.

#### Evaluation

Tasks 1 and 3 will be evaluated using the [Meeting Preparation Grading Standards](https://sta518.github.io/syllabus/assessment/#meeting-preparation-1).
Each subtask in Task 2 will each be evaluated using the [Application Tasks Grading Standards](https://sta518.github.io/syllabus/assessment/#application-tasks-1).

Your overall Application Task 3 grade will be based on the following criteria:

- Excellent (**E**): Each task earned an Excellent of Satisfactory, including one Excellent.
- Satisfactory (**S**): Each task earned a Satisfactory.
- Progressing (**P**): Each task earned a Satisfactory or Progressing.
- Incomplete (**I**): At least one task was not submit.

### Create Your `application03` Repo

GitHub Classroom will automatically make a repository for you, called `application03-your_github_username`, for you to work on your assignment.
Follow these instructions to get the repo:

1. Sign-in to [Bb](https://mybb.gvsu.edu)
2. Go to the **Application Task 3** assignment page.

Here, you will find a url leading to a page on GitHub Classroom.
Visit this page and follow the instructions.
When you obtain your repository, it should contain a copy of this `application03-instructions.md` file, a blank `README.md` file, and a starter `application03Rmd` file.

#### 1. Edit `README.md` 

Your task here is to edit the `README.md` file in your repository to contain a sample of GitHub-flavored markdown features.
Specifically, your README should contain a brief description as to what the repo is, so that an unknown visitor landing on the repo can orient themselves
You should also help the visitor navigate your repository (in whatever way you think is most appropriate).

Remember the resources you were directed to view during your work in the class activities and Meeting Preparations.
These are also organized in the [Additional Resources/Markdown](https://sta518.github.io/resources/markdown/) section of this site.

You can edit the README in your browser like we did in class, but I encourage you to experiment with editing it from within RStudio.
**FYI, this will be a private repo - only you and I will be able to see it.**

#### 2. Exploration with R Markdown

This task explores a dataset.
Edit the R Markdown document and your final submission should include both text and code intertwined.
If you simply complete each subtask, this would be considered *sufficient*.
Effectively adding your own creative twist, without being distracting for each the subtasks, would be considered *excellent*.

You will be using data collected from the General Social Survey (GSS) that is maintained at the[GSS Data Explorer](https://gssdataexplorer.norc.org).
The GSS gathers data on contemporary American society in order to monitor and explain trends and constants in attitudes, behaviors, and attributes. 
In this lab we analyze data from the 2016 GSS, using it to estimate values of population parameters of intertest about US adults.

Knit your completed `.Rmd` file.
Commit and push to GitHub your `.Rmd` file and the `.md` and `application03-img` folder that are automatically created when you knit.

##### Data

As mentioned above, you will work with the 2016 GSS data.
The public release of this data contains 935 variables and 2867 observations.
This is not a massive data set, but it is a fairly large that we need to consider how we handle it in our workflow.

The size of the data file we're working with it 34.3 MB (the professor evaluations data was 45KB). which means the GSS data is a little over 750 times the size of the evaluations data. That's a big difference! 
GitHub produces a warning when you push files larger than 50 MB, and it will not allow files larger than 100 MB (see [GitHub Help - Working with large files](https://help.github.com/articles/working-with-large-files/))
While this file is smaller than both of these limits, it's still large enough to not push to GitHub.

This is where the `.gitignore` file comes into play.
The `.gitignore` file contains a list of the files you don't want to to commit to Git or push to GitHub.
If you open the `.gitignore` file in your project repo, you'll see that the data file, `gss2016.csv`, is already listed there.

- Mine Çetinkaya-Rundel provides the data [here](https://stat.duke.edu/~mc301/data/gss2016.csv) (otherwise you would need to set-up an account to download from the GSS Data Explorer site). The file is called `gss2016.csv`.  
- Navigate to the data folder in your RStudio project and upload the `gss2016.csv` file.
- Note that even though you made a change in your files by adding the data, `gss2016.csv` does not appear in your Git pane. This is because it's being ignored by git.

Add the following code to your `load-data` R chunk.


```r
gss <- read_csv("data/gss2016.csv",
                na = c("", "Don't know",
                       "No answer", "Not applicable"),
                guess_max = 2867) %>%
  select(harass5, emailmin, emailhr, educ, born, polviews, advfront)
```

Notice that this chunk does two things:

1. `guess_max`: In the documentation for `read_csv` yousee that the function uses the first 1,000 observations from a data frame to determine the classes of each variable. However, in this data frame, we have numeric data within the first 1,000 rows, but then something like `"8 or more"` in later rows. Therefore, without specifically telling R to scan all rows to determine the variable class, we would end up with some warnings when loading the data. Feel free to experiment with this by removing the `guess_max` argument.
2. `select`: In this Application Task, I know which variables you will be using from the data, so you can just select those and not load the entire dataset. This is extrememly helpful when working with large data sets. Now, you might be wondering how you would know ahead of time which variables you will be working with. Valid and you probably won't know.  However, once you make up your mind, you can always go back and add a `select()` so that from that point onwards you can benefit from faster computation in your analysis.

###### Set a seed!

In this application you will be bootstrapping, which means we'll be generating random samples.
The last thing you want is those samples to change every time you knit your document.
So, you should set a seed.
In the `set-seed` R chunk in your R Markdown file set aside for this.
Locate it and add a seed value that is the [house number](https://en.wikipedia.org/wiki/Address#United_States) of your home address.
For example, if you lived inside the Devos Center (201 Front Ave. SW, Grand Rapids, MI 49504), your house number would be `201`.

##### 2.1: Harrassment at work

In 2016, the GSS added a new question on harrassment at work.
The question is phrased as the following.

> Over the past five years, have you been harassed by your superiors or co-workers at your job, for example, have you experienced any bullying, physical or psychological abuse?

Answers to this question are stored in the `harass5` variable in our dataset.

To accomplish this task, complete the following steps.
Note that if you choose to simply step through these items (successfully), that would be considered *satisfactory*.
Effective use of narrative and output would be considered *excellent*.

1. What are the possible responses to this question and how many respondents chose each of these answers?  

2. Filter the data for only those who answered `"Yes"` or `"No"` to this question.  The `%in%` operator will be helpful here as well as in the rest of the Application Task.  However, do not overwrite the data frame (as you'll need the full data in later tasks). Instead save the resulting data frame with a new name.

3. What percent of the respondents who answereed `"Yes"` or `"No"` to this question have been harassed by their superiors or co-workers at their job?

4. Construct and visualize a bootstrap distribution for the proportion of Americans who have been harrassed at work. Use this general form as a recipe:


```r
# save resulting bootstrap distribution
variable_ci_statistic <- dataset %>%
  # specify the variable of interest
  specify(response = variable) %>% 
  # generate 15000 bootstrap samples
  generate(reps = 15000, type = "bootstrap") %>% 
  # calculate the "statistic" of each bootstrap sample
  calculate(stat = "statistic")
```

Since you are constructing a simulation for a *proportion*, use `stat = "prop"` in the `calculate` function. Note that when the response variable is categorical, we need to supply an additional argument to the `specify` function that specifies the level which we want to consider as `success`. In this case, since we're interested in proportion of Americans who have been harrassed, we're interested in `success = "Yes"`.

Ideally, you should be using 15,000 simulations (`rep = 15000`); however, you might find that repeatedly knitting your document with 15,000 simulations for each bootstrap interval will slow things down. Therefore, develop your answers with a small number of simulations, like `rep = 100`. Then, once you have everything working go back and change these numbers to `rep = 15000`.  **I will remind you prior to Task 3 to make this change.**

Don't forget to plot your distribution of proportions of Americans who have been harrassed at work.

5. Determine the 95% bootstrap confidence interval based on the distribution you constructed above.  Summarize your bootstrap distribution by determine the lower bound (2.5^th^ percentile) and upper bound (97.5^th^ percentile).  The `quantile` function will be helpful here as well asin the rest of the Application Task.  *Brownie points* if you can add these values to your plot from [4].  Interpret the confidence interval in context of the data.

##### An example

You do not have anything to do in this section, but parts of this will help you with your submistion for Task 2.2 and other parts are just for completeness.

Another question on the 2016 GSS was how many years of schooling they completed.
The distribution of responses is as follows:


```r
ggplot(data = gss, mapping = aes(x = educ)) +
  geom_histogram(binwidth = 1, fill = "white", color = "black") +
  theme_minimal()
```

![](application03-instructions_files/figure-html/unnamed-chunk-4-1.png)<!-- -->

Here we want to estimate difference between the average numbers of years of education between those who were born in this country (`born = "Yes"`) and those who were not (`born = "No"`).
We will construct a confidence interval for the difference between the population averages of number of years of education between these two groups, i.e. for ($\mu_{Yes} - \mu_{No}$) where $\mu$ is the average number of years of education.

We see that some respondents either did not answer the`born` question, or they did not know, or thought the question did not apply to them.
When you read in the data, these responses were coded as `NA`.


```r
gss %>%
  count(born)
```

```
## # A tibble: 3 x 2
##   born      n
##   <chr> <int>
## 1 No      355
## 2 Yes    2507
## 3 <NA>      5
```

Similarly, we can see that some respondents did not answer the education question:


```r
gss %>%
  count(educ) %>% 
  print(n = Inf)
```

```
## # A tibble: 22 x 2
##     educ     n
##    <dbl> <int>
##  1     0     2
##  2     1     3
##  3     2     3
##  4     3     3
##  5     4     2
##  6     5     4
##  7     6    31
##  8     7    18
##  9     8    48
## 10     9    59
## 11    10    90
## 12    11   118
## 13    12   824
## 14    13   242
## 15    14   359
## 16    15   137
## 17    16   485
## 18    17   108
## 19    18   149
## 20    19    63
## 21    20   110
## 22    NA     9
```

In order to make sure that we are bootstrapping observations for which we have data, we will first filter for non-`NA` values and create a new data frame.


```r
gss_educ <- gss %>%
  filter(
    !is.na(educ),
    !is.na(born)
  )
```

To produce a bootstrap interval for the difference between the average number of years of education between those born and not born in the US we will: 

1. Take a bootstrap sample of those born in the US and a bootstrap sample of those not born in the US. These are random samples, taken with replacement, from the original samples, of the same size as the original samples.

2. Calculate the bootstrap statistic - in this case we find the mean of each of the bootstrap samples and take the difference between them.

3. Repeat steps (1) and (2) many times to create a bootstrap distribution for differences in means.

4. Calculate the bounds of the XX% confidence interval as the middle XX% of the bootstrap distribution.

In this new setup, our model has changed.
We `specify` the `response` and `explanatory` variables. 
Here, the explanatory variable is the one to be used for splitting the data into the groups.
Aso, we now need to specify the order in which to subtract the mean numbers of years of education in (2) above
For example, `born = "Yes"` - `born = "No"`.


```r
diff_educ_born_boot <- gss_educ %>%
  specify(response = educ, explanatory = born) %>%
  generate(reps = 100, type = "bootstrap") %>%
  calculate(stat = "diff in means", order = c("Yes", "No"))
```

Again, we will plot the distribution of these bootstrap differences in means.

![](application03-instructions_files/figure-html/unnamed-chunk-9-1.png)<!-- -->

Finally, we can say that we are 99% confident that the difference between the average number of years of education between those born and not born in the US is between 0.21 and 1.19 years.

##### 2.2: Liberals vs. Conservatives - Is science research necessary?

The 2016 GSS also asked respondents whether they think of themselves as liberal or conservative (`polviews`) and whether they think science research is necessary and should be supported by the federal government (`advfront`).

The question on science research is worded as follows:

> Even if it brings no immediate benefits, scientific research that advances the frontiers of knowledge is necessary and should be supported by the federal government.

Possible responses to this question are "Strongly agree", "Agree", "Disagree", "Strongly disagree", "Dont know", "No answer", "Not applicable".

The question on political views is worded as follows:

> We hear a lot of talk these days about liberals and conservatives. I'm going to show you a seven-point scale on which the political views that people might hold are arranged from extremely liberal--point 1--to extremely conservative--point 7. Where would you place yourself on this scale?
  
Possible responses to this question are "Extremely liberal", "Liberal", "Slightly liberal", "Moderate", "Slghtly conservative", "Conservative", "Extrmly conservative".
Responses that were originally "Don't know", "No answer", and "Not applicable" are already mapped to `NA`s (we did this in the data import).
Also, note that the levels of this variables are spelled inconsistently: "Extremely liberal" vs. "Extrmly conservative" and "Slightly liberal" vs. "Slghtly conservative".
Since this is the spelling that shows up in the data, you need to make sure this is how you spell the levels in your code or correct it.

1. Mutate a new variable, i.e., recode `advfront`, such that "Strongly agree" and "Agree" are mapped to `"Yes"`, and "Disagree" and "Strongly disagree" are mapped to `"No"`. The remaining levels can be left as is.

2. Mutate a new variable, i.e., recode `polviews`, such that "Extremely liberal", "Liberal", and "Slightly liberal", are mapped to `"Liberal"`, and "Slghtly conservative", "Conservative", and "Extrmly conservative" are mapped to `"Conservative"`. The remaining levels can be left as is.

3. Filter the data for respondents who self-identified as "liberal" or "conservative" and who responded "yes" or "no" to the science research question. Save the resulting data frame with a different name so that you don't overwrite the data.

4. Describe how you will use bootstrapping to estimate the difference in proportion of liberals and not liberals who think science research is necessary and should be supported by the federal government.

5. Construct a 90% bootstrap confidence interval for the difference in proportion of liberals and conservatives who think science research is necessary and should be supported by the federal government. Interpret this interval in context of the data.

**Remember to go back and change `reps = 100` to `reps = 15000` in Task 2.1, An Example, and Task 2.2.**

#### 3. Reflection
  
After you have completed Tasks 1 and 2 go back to the **Application Task 3** assignment page on [Bb](https://mybb.gvsu.edu).
You will submit your reflection here that minimally includes:

- A clickable link to your Application Task 3 repository.
- A reflection on what was hard/easy, problems you came across and how you solved them, helpful tutorials you read, etc.
