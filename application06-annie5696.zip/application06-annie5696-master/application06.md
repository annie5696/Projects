---
title: "Application Task 6"
author: "Anisha Shrestha"
date: "11/15/2019"
output: 
  html_document: 
    keep_md: yes
---


##### 2.3 Work with a list

Loading the datasets. Downlaod the datasets using the link and upload in the working directory. 
loading the library purrr, it allows us to map functions to data. We use `suppressMessages` in order to supress extra message while loading the library `dplyr`. Glimpse function will show maximum number of columns that are in our datasets.


```r
library(purrr)
suppressMessages(library(dplyr))
library(tibble)

load(url("http://varianceexplained.org/files/trump_tweets_df.rda"))
load("trump_tweets_df.rda")
glimpse(trump_tweets_df)
```

```
## Observations: 1,512
## Variables: 16
## $ text          <chr> "My economic policy speech will be carried live at 12:1…
## $ favorited     <lgl> FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,…
## $ favoriteCount <dbl> 9214, 6981, 15724, 19837, 34051, 29831, 19223, 19543, 7…
## $ replyToSN     <chr> NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,…
## $ created       <dttm> 2016-08-08 15:20:44, 2016-08-08 13:28:20, 2016-08-08 0…
## $ truncated     <lgl> FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,…
## $ replyToSID    <lgl> NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,…
## $ id            <chr> "762669882571980801", "762641595439190016", "7624396589…
## $ replyToUID    <chr> NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,…
## $ statusSource  <chr> "<a href=\"http://twitter.com/download/android\" rel=\"…
## $ screenName    <chr> "realDonaldTrump", "realDonaldTrump", "realDonaldTrump"…
## $ retweetCount  <dbl> 3107, 2390, 6691, 6402, 11717, 9892, 5784, 7930, 24663,…
## $ isRetweet     <lgl> FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,…
## $ retweeted     <lgl> FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,…
## $ longitude     <chr> NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,…
## $ latitude      <chr> NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,…
```


First `tweets` takes all the text from the tweets. Similarly, Second only selectes the number of string. In this case, it chooses 70 string.


```r
tweets <- trump_tweets_df$text
tweets %>% head() %>% strtrim(70)
```

```
## [1] "My economic policy speech will be carried live at 12:15 P.M. Enjoy!"   
## [2] "Join me in Fayetteville, North Carolina tomorrow evening at 6pm. Ticke"
## [3] "#ICYMI: \"Will Media Apologize to Trump?\" https://t.co/ia7rKBmioA"    
## [4] "Michael Morell, the lightweight former Acting Director of C.I.A., and "
## [5] "The media is going crazy. They totally distort so many things on purpo"
## [6] "I see where Mayor Stephanie Rawlings-Blake of Baltimore is pushing Cro"
```

(regex) Regular expression tester with syntax highlighting, where we choose some of the words from his tweets badly, crazy, weak, spent, strong, dumb, joke, guns, funny and dead 


```r
regex <- "badly|crazy|weak|spent|strong|dumb|joke|guns|funny|dead"
```


The first steps is taking the number of tweets that are under 1, 2 .. 919 rows and making it as a new vector and strtrim showing string count to 70 including space.


```r
tweets <- tweets[c(1, 2, 5, 6, 198, 347, 919)]
tweets %>% strtrim(70)
```

```
## [1] "My economic policy speech will be carried live at 12:15 P.M. Enjoy!"   
## [2] "Join me in Fayetteville, North Carolina tomorrow evening at 6pm. Ticke"
## [3] "The media is going crazy. They totally distort so many things on purpo"
## [4] "I see where Mayor Stephanie Rawlings-Blake of Baltimore is pushing Cro"
## [5] "Bernie Sanders started off strong, but with the selection of Kaine for"
## [6] "Crooked Hillary Clinton is unfit to serve as President of the U.S. Her"
## [7] "The Cruz-Kasich pact is under great strain. This joke of a deal is fal"
```

gregexpr function enables retrieval of the matching substrings character containing string of regular expression where each element is searched separately. gregexpr function has the return objects in the form of list rather than a vector. It matched the word that was in `regex` with the tweets dataframe and keeps in matches. str(matches) shows the list of 7 matched tweets. Returns each elements in a interger vector, if it matches the character, it holds the positions of the first character and if not matched then returned -1, with attribute "match.length", an integer vector giving the length of the matched text (or -1 for no match). The match positions and lengths are in characters unless useBytes= TRUE is used, when they are in bytes. 




```r
matches <- gregexpr(regex, tweets)
str(matches)
```

```
## List of 7
##  $ : int -1
##   ..- attr(*, "match.length")= int -1
##   ..- attr(*, "index.type")= chr "chars"
##   ..- attr(*, "useBytes")= logi TRUE
##  $ : int -1
##   ..- attr(*, "match.length")= int -1
##   ..- attr(*, "index.type")= chr "chars"
##   ..- attr(*, "useBytes")= logi TRUE
##  $ : int 20
##   ..- attr(*, "match.length")= int 5
##   ..- attr(*, "index.type")= chr "chars"
##   ..- attr(*, "useBytes")= logi TRUE
##  $ : int 134
##   ..- attr(*, "match.length")= int 4
##   ..- attr(*, "index.type")= chr "chars"
##   ..- attr(*, "useBytes")= logi TRUE
##  $ : int [1:2] 28 95
##   ..- attr(*, "match.length")= int [1:2] 6 4
##   ..- attr(*, "index.type")= chr "chars"
##   ..- attr(*, "useBytes")= logi TRUE
##  $ : int [1:2] 87 114
##   ..- attr(*, "match.length")= int [1:2] 4 6
##   ..- attr(*, "index.type")= chr "chars"
##   ..- attr(*, "useBytes")= logi TRUE
##  $ : int [1:3] 50 112 123
##   ..- attr(*, "match.length")= int [1:3] 4 4 4
##   ..- attr(*, "index.type")= chr "chars"
##   ..- attr(*, "useBytes")= logi TRUE
```

```r
matches[[7]]
```

```
## [1]  50 112 123
## attr(,"match.length")
## [1] 4 4 4
## attr(,"index.type")
## [1] "chars"
## attr(,"useBytes")
## [1] TRUE
```


length() would just give the length of the vector containing the string, which will be 1 if the string is just a single string.
sapply() will silently return a list, vapply() takes an additional argument specifying the output type. map_int() always return an interger vector and in the form of list.




```r
lengths(matches)  
```

```
## [1] 1 1 1 1 2 2 3
```

```r
sapply(matches, length) 
```

```
## [1] 1 1 1 1 2 2 3
```

```r
vapply(matches, length, integer(1)) 
```

```
## [1] 1 1 1 1 2 2 3
```

```r
map_int(matches, length)  
```

```
## [1] 1 1 1 1 2 2 3
```


We are trying to get the list of match elements. Matches are in the first string (at 50 with length 4) and third string (at 123 with length 4): Vector from the attribute are described below. 


```r
m <- matches[[7]]
match_length<- matches[[7]]
attr(m, which = "match.length")
```

```
## [1] 4 4 4
```

```r
attr(m, which = "index.type")
```

```
## [1] "chars"
```

Here, we are making a custom functions that returns all the matches by using map functions where we send matches and m1 as an arguements.


```r
ml <- function(x) attr(x, which = "match.length")
map(matches, ml)
```

```
## [[1]]
## [1] -1
## 
## [[2]]
## [1] -1
## 
## [[3]]
## [1] 5
## 
## [[4]]
## [1] 4
## 
## [[5]]
## [1] 6 4
## 
## [[6]]
## [1] 4 6
## 
## [[7]]
## [1] 4 4 4
```

Use anonymous map functions to get matches by length. If no match found then It returns -1 and of the match found then it returns the length


```r
map(matches, ~ attr(.x, which = "match.length"))
```

```
## [[1]]
## [1] -1
## 
## [[2]]
## [1] -1
## 
## [[3]]
## [1] 5
## 
## [[4]]
## [1] 4
## 
## [[5]]
## [1] 6 4
## 
## [[6]]
## [1] 4 6
## 
## [[7]]
## [1] 4 4 4
```

This is pre-existing functions where we pass additional arguements. like attr, matches and find the match.length.


```r
(match_length <- map(matches, attr, which = "match.length"))
```

```
## [[1]]
## [1] -1
## 
## [[2]]
## [1] -1
## 
## [[3]]
## [1] 5
## 
## [[4]]
## [1] 4
## 
## [[5]]
## [1] 6 4
## 
## [[6]]
## [1] 4 6
## 
## [[7]]
## [1] 4 4 4
```

> Exercise: Count the number of Trump Android words in each tweet.

While doing this, we could use previous , length(matches) function, but this will return -1 to the unmatched values which we dont want here. We wanted to count the number of Trump Android words in each tweet.

For this, we first divided the task with two ways, we pick tweet with 0 trump word and another one with 3. The following codes, will simply return either 0 or 3 based on the match count.



```r
m <- matches[[1]]
sum(m > 0)
```

```
## [1] 0
```

```r
m <- matches[[7]]
sum(m > 0)
```

```
## [1] 3
```

After this, we use one of this approach to insert purr::map() and apply to matches. The function below automatically returns the sum of matches by using purr::map()


```r
f <- function(x) sum(x > 0)
map(matches, f)
```

```
## [[1]]
## [1] 0
## 
## [[2]]
## [1] 0
## 
## [[3]]
## [1] 1
## 
## [[4]]
## [1] 1
## 
## [[5]]
## [1] 2
## 
## [[6]]
## [1] 2
## 
## [[7]]
## [1] 3
```

We could use any of the two functions which gives us similar result.


```r
map(matches, ~ sum(.x > 0))
```

```
## [[1]]
## [1] 0
## 
## [[2]]
## [1] 0
## 
## [[3]]
## [1] 1
## 
## [[4]]
## [1] 1
## 
## [[5]]
## [1] 2
## 
## [[6]]
## [1] 2
## 
## [[7]]
## [1] 3
```

> Tweak your existing approach to return an integer vector, with length equal to the number of tweets.

The function is same as above instead, we use map_int to return an interger values with the length equal to the number of tweets.


```r
map_int(matches, ~ sum(.x > 0))
```

```
## [1] 0 0 1 1 2 2 3
```

naive_length gives the length for the match whereas n_words, will give the interger values for count of the match. 


```r
tibble(
  naive_length = lengths(matches),
  n_words = map_int(matches, ~ sum(.x > 0))
)
```

```
## # A tibble: 7 x 2
##   naive_length n_words
##          <int>   <int>
## 1            1       0
## 2            1       0
## 3            1       1
## 4            1       1
## 5            2       2
## 6            2       2
## 7            3       3
```



Here, We are trying to strip the attributes from matches and return as a vector. We are creating a copy of matches with different name called `match_first` This removes the attributes from the elements of `matches`. This will only print the vector information apart from whole output.


```r
(match_first <- map(matches, as.vector))
```

```
## [[1]]
## [1] -1
## 
## [[2]]
## [1] -1
## 
## [[3]]
## [1] 20
## 
## [[4]]
## [1] 134
## 
## [[5]]
## [1] 28 95
## 
## [[6]]
## [1]  87 114
## 
## [[7]]
## [1]  50 112 123
```


 The first strtrim function will print 70 character of the tweets. Similarly, if there is no match then it will return -1. In the first two sentecnes there is no match, thus, it returned -1. Similarly, If there is a match then it will return the position of of the character where its matched in the form of vector.


```r
tweets %>% strtrim(70)
```

```
## [1] "My economic policy speech will be carried live at 12:15 P.M. Enjoy!"   
## [2] "Join me in Fayetteville, North Carolina tomorrow evening at 6pm. Ticke"
## [3] "The media is going crazy. They totally distort so many things on purpo"
## [4] "I see where Mayor Stephanie Rawlings-Blake of Baltimore is pushing Cro"
## [5] "Bernie Sanders started off strong, but with the selection of Kaine for"
## [6] "Crooked Hillary Clinton is unfit to serve as President of the U.S. Her"
## [7] "The Cruz-Kasich pact is under great strain. This joke of a deal is fal"
```

```r
match_first
```

```
## [[1]]
## [1] -1
## 
## [[2]]
## [1] -1
## 
## [[3]]
## [1] 20
## 
## [[4]]
## [1] 134
## 
## [[5]]
## [1] 28 95
## 
## [[6]]
## [1]  87 114
## 
## [[7]]
## [1]  50 112 123
```

```r
match_length
```

```
## [[1]]
## [1] -1
## 
## [[2]]
## [1] -1
## 
## [[3]]
## [1] 5
## 
## [[4]]
## [1] 4
## 
## [[5]]
## [1] 6 4
## 
## [[6]]
## [1] 4 6
## 
## [[7]]
## [1] 4 4 4
```

In this example, we are trying to get the trump tweet from 1 and form 7 where 1 has no match at all and 7 has 3 match of the trump word. We will start with 7, where there are three trump words. `t_first` will give us the position of length that the word matches in the sentence. `t_length` witll give use the total length of the match. For example, `GREAT`,`JOKE`,`DEAD` which has 4 character length match in the tweet. `T_last` will add the first length and the word count length where we delete 1 to only select the word that matches in the tweets. `Substring` will give the output from the sentence, and gives the word `joke` , `dead` and `dumb` from 7. 


```r
(tweet <- tweets[7])
```

```
## [1] "The Cruz-Kasich pact is under great strain. This joke of a deal is falling apart, not being honored and almost dead. Very dumb!"
```

```r
(t_first <- match_first[[7]])
```

```
## [1]  50 112 123
```

```r
(t_length <- match_length[[7]])
```

```
## [1] 4 4 4
```

```r
(t_last <- t_first + t_length - 1)
```

```
## [1]  53 115 126
```

```r
substring(tweet, t_first, t_last)
```

```
## [1] "joke" "dead" "dumb"
```

> How well does this code work for tweet #1, with 0 Trump words?

For 1, we dont have any match word and if we repeat the same process, form 1, we get nothing.


```r
(tweet <- tweets[1])
```

```
## [1] "My economic policy speech will be carried live at 12:15 P.M. Enjoy!"
```

```r
(t_first <- match_first[[1]])
```

```
## [1] -1
```

```r
(t_length <- match_length[[1]])
```

```
## [1] -1
```

```r
(t_last <- t_first + t_length - 1)
```

```
## [1] -3
```

```r
substring(tweet, t_first, t_last)
```

```
## [1] ""
```

> Store where Trump words end

In this step, we are trying to make a list where trump word ends. We call this as `match_last` This is another map()-type problem, but instead of mapping over one list, we need to map over 2 lists in parallel.

formula, e.g. ~ .x + .y, it is converted to a function. There are three ways to refer to the arguments: But here we use two way arguement function. `x` and `y` .


```r
(match_last <- map2(match_first, match_length, ~ .x + .y - 1))
```

```
## [[1]]
## [1] -3
## 
## [[2]]
## [1] -3
## 
## [[3]]
## [1] 24
## 
## [[4]]
## [1] 137
## 
## [[5]]
## [1] 33 98
## 
## [[6]]
## [1]  90 119
## 
## [[7]]
## [1]  53 115 126
```

We use another map function to match, In this problem, instead of using mapping over 1 list, we are trying to map over 3 list in parallel. We have `pmap()` for this. They are parallel in the sense that each input is processed in parallel with the others, not in the sense of multicore computing. pmap() allow us to provide any number of arguments in a list. Here is list, so this is converted into extractor function. Character vectors index by name and numeric vectors index by position; list to index by position and name at different levels. If a component is not present, the value of .default will be returned. List names will be used if present.



```r
pmap(list(text = tweets, first = match_first, last = match_last), substring)
```

```
## [[1]]
## [1] ""
## 
## [[2]]
## [1] ""
## 
## [[3]]
## [1] "crazy"
## 
## [[4]]
## [1] "joke"
## 
## [[5]]
## [1] "strong" "weak"  
## 
## [[6]]
## [1] "weak"   "strong"
## 
## [[7]]
## [1] "joke" "dead" "dumb"
```

> March through the rows in a data frame

While trying to match the words from the tweets, and get into a dataframe, we use pmap and functions and substring for extracting the text. the first two sentences do not have any matches, thus, it returned nothing. Similarly, after third, we can see the word matched and how we extracted using pmap. It is always safe and better to approach it in a row in a dataframe. We can always see how our dataframe stands. 


```r
mdf <- tibble(
  text = tweets,
  first = match_first,
  last = match_last
)
pmap(mdf, substring)
```

```
## [[1]]
## [1] ""
## 
## [[2]]
## [1] ""
## 
## [[3]]
## [1] "crazy"
## 
## [[4]]
## [1] "joke"
## 
## [[5]]
## [1] "strong" "weak"  
## 
## [[6]]
## [1] "weak"   "strong"
## 
## [[7]]
## [1] "joke" "dead" "dumb"
```

> What if we take it all from the top, using a data frame approach and being as concise as possible

In this process, we are doing the same, instead we are providing x and y arguements and substracting length 1. The first step is to get the tweets into text objects. match the text values with tweets using `gregexpr` functions. We use map functions to match first word in the sentences using match.length. We also try to map with the last word and substract the overlaping value i.e -1. Deselect `match_length`. Thus, we can get the matched words using pmap(substring).


```r
tibble(text = tweets,
       first = gregexpr(regex, tweets)) %>% 
  mutate(match_length = map(first, ~ attr(.x, which = "match.length")),
         last = map2(first, match_length, ~ .x + .y - 1)) %>%
  select(-match_length) %>% 
  pmap(substring)
```

```
## [[1]]
## [1] ""
## 
## [[2]]
## [1] ""
## 
## [[3]]
## [1] "crazy"
## 
## [[4]]
## [1] "joke"
## 
## [[5]]
## [1] "strong" "weak"  
## 
## [[6]]
## [1] "weak"   "strong"
## 
## [[7]]
## [1] "joke" "dead" "dumb"
```

If we want to solve the problem, we could post process the output of `gregexpr()` with `regmatches()`.
Or we could also use stringr or stringi packages to avoid gregexpr() altogether. If there is no match in the words, we return 0. In the first two sentences, there is no match thus, we get 0.


> Appendix


```r
regmatches(tweets, gregexpr(regex, tweets))
```

```
## [[1]]
## character(0)
## 
## [[2]]
## character(0)
## 
## [[3]]
## [1] "crazy"
## 
## [[4]]
## [1] "joke"
## 
## [[5]]
## [1] "strong" "weak"  
## 
## [[6]]
## [1] "weak"   "strong"
## 
## [[7]]
## [1] "joke" "dead" "dumb"
```

This shows the function for regmatches and how this works.


```r
regmatches
```

```
## function (x, m, invert = FALSE) 
## {
##     if (length(x) != length(m)) 
##         stop(gettextf("%s and %s must have the same length", 
##             sQuote("x"), sQuote("m")), domain = NA)
##     ili <- is.list(m)
##     itype <- "chars"
##     useBytes <- if (ili) 
##         any(unlist(lapply(m, attr, "index.type")) == "bytes")
##     else any(attr(m, "index.type") == "bytes")
##     if (useBytes) {
##         itype <- Encoding(x) <- "bytes"
##     }
##     if (!ili && isFALSE(invert)) {
##         so <- m[ind <- (!is.na(m) & (m > -1L))]
##         eo <- so + attr(m, "match.length")[ind] - 1L
##         return(substring(x[ind], so, eo))
##     }
##     y <- if (is.na(invert)) {
##         Map(function(u, so, ml) {
##             if ((n <- length(so)) == 1L) {
##                 if (is.na(so)) 
##                   return(NA_character_)
##                 else if (so == -1L) 
##                   return(u)
##             }
##             eo <- so + ml - 1L
##             if (n > 1L) {
##                 if (any(eo[-n] >= so[-1L])) 
##                   stop(gettextf("need non-overlapping matches for %s", 
##                     sQuote("invert = NA")), domain = NA)
##             }
##             beg <- c(1L, c(rbind(so, eo + 1L)))
##             end <- c(c(rbind(so - 1L, eo)), nchar(u, itype))
##             substring(u, beg, end)
##         }, x, m, if (ili) 
##             lapply(m, attr, "match.length")
##         else attr(m, "match.length"), USE.NAMES = FALSE)
##     }
##     else if (invert) {
##         Map(function(u, so, ml) {
##             if ((n <- length(so)) == 1L) {
##                 if (is.na(so)) 
##                   return(NA_character_)
##                 else if (so == -1L) 
##                   return(u)
##             }
##             beg <- if (n > 1L) {
##                 eo <- so + ml - 1L
##                 if (any(eo[-n] >= so[-1L])) 
##                   stop(gettextf("need non-overlapping matches for %s", 
##                     sQuote("invert = TRUE")), domain = NA)
##                 c(1L, eo + 1L)
##             }
##             else {
##                 c(1L, so + ml)
##             }
##             end <- c(so - 1L, nchar(u, itype))
##             substring(u, beg, end)
##         }, x, m, if (ili) 
##             lapply(m, attr, "match.length")
##         else attr(m, "match.length"), USE.NAMES = FALSE)
##     }
##     else {
##         Map(function(u, so, ml) {
##             if (length(so) == 1L) {
##                 if (is.na(so) || (so == -1L)) 
##                   return(character())
##             }
##             substring(u, so, so + ml - 1L)
##         }, x, m, lapply(m, attr, "match.length"), USE.NAMES = FALSE)
##     }
##     names(y) <- names(x)
##     y
## }
## <bytecode: 0x63a2fd0>
## <environment: namespace:base>
```

#### For Task 2.4


This will increase the graph height and width in output.


```r
knitr::opts_chunk$set(fig.width=20, fig.height=8)
```


Loading the library


```r
options(warn = -1)
library(tidyverse)
```

```
## ── Attaching packages ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── tidyverse 1.3.0 ──
```

```
## ✔ ggplot2 3.2.1     ✔ stringr 1.4.0
## ✔ tidyr   1.0.0     ✔ forcats 0.4.0
## ✔ readr   1.3.1
```

```
## ── Conflicts ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── tidyverse_conflicts() ──
## ✖ dplyr::filter() masks stats::filter()
## ✖ dplyr::lag()    masks stats::lag()
```

```r
library(robotstxt)
library(rvest)
```

```
## Loading required package: xml2
```

```
## 
## Attaching package: 'rvest'
```

```
## The following object is masked from 'package:readr':
## 
##     guess_encoding
```

```
## The following object is masked from 'package:purrr':
## 
##     pluck
```


Reading the data name `paygap.csv`. The values after decimal is rounded up and we do not include values after decimal.


```r
paygap <- read_csv("data/paygap.csv")
```

```
## Parsed with column specification:
## cols(
##   county = col_character(),
##   women = col_double(),
##   men = col_double(),
##   ratio = col_double()
## )
```

```r
paygap2<- paygap %>% mutate_at(vars(ratio), funs(round(., 0)))
```


The graphs shows the ratio of male by female income ratio based on country where `ratio > 2` on y-axis and `county` on x-axis shows `yemen` having the highest values of 15 followed by `Syria` with values 7. Similarly, Countries like `Afganistan` and `Jordan` have the ratio value of 6. On the other side, The countries like, `Bangladesh`, `Bahrain`, `Maldives`, `Srilanka`, `Mauritania`, `Timor-Leste` have the lowest value of 3. This roughly shows that middlest counties are male dominant in income while the south asian countries have very less income gap between male and female with some of the countries being exception like UAE `United Arab Emirates` having the lower gross income ratio.




```r
paygap2 %>%
    group_by(county,ratio) %>%
    tally() %>%
  arrange(ratio) %>%
 filter(ratio>2) -> paygap2 

ggplot(data=paygap2, aes(x= reorder(county, -ratio), y=ratio)) + geom_bar(stat="identity", fill="blue")+ geom_text(aes(label=ratio), vjust=-0.3, size=5)+ 
     theme(axis.text.x = element_text(angle=50, hjust=0, vjust=-0.01))+ggtitle("Countries by male to female income ratio 2017 in 2011 USD PPP (2017)") + labs(x="country")
```

![](application06_files/figure-html/unnamed-chunk-29-1.png)<!-- -->
























































