
library(rvest)
library(stringr)


county <- imdb_page %>% 
  html_nodes("td:nth-child(1)") %>% 
  html_text()  %>%
  str_replace("\\n", "")%>%
  str_replace("\\n", "")


women <- imdb_page %>% 
  html_nodes("td:nth-child(2)") %>% 
  html_text()  %>%
  str_replace("\\n", "")
women<- as.numeric(gsub(",", "", women))



men <- imdb_page %>% 
  html_nodes("td:nth-child(3)") %>% 
  html_text() %>%
  str_replace("\\n", "")
men<- as.numeric(gsub(",", "", men))


ratio<- imdb_page %>%
  html_nodes("td:nth-child(4)") %>% 
  html_text()%>%
  str_replace("\\n", "")
ratio<- as.numeric(gsub(",", "", ratio))


#combines the pulled data into a tibble
paygap <- tibble(county = county,
                 women = women,
                 men = men,
                 ratio= ratio
)


write_csv(paygap, path = "data/paygap.csv")




