# Application06 - STA518 FAL19

For application 06, I choose: `2.3` and `2.4`.

This repo contains the following information about the Application 06:

1. [Instructions](https://github.com/sta518/application06-annie5696/blob/master/application06-instructions.Rmd)

2. [R Markdown Document 2.3 and 2.4](https://github.com/sta518/application06-annie5696/blob/master/application06.Rmd)

3. [This readme file](https://github.com/sta518/application06-annie5696/blob/master/README.md)


Data taking from the wikipedia page :  [List of countries by male to female income ratio](https://en.wikipedia.org/wiki/List_of_countries_by_male_to_female_income_ratio)


> The above mentioned page is the Gender Development Index. There are total 168 countries by female to male income ratio in 2011  USD PPP (2017). The ratio is determined by comparing the gross national income per woman with the gross national income per man in 2017


The RMD file shows a graphs for countries by ratio of male to female, where we choose ratio greater than 2. There are many repeated numbers(ratio) for many countries.