---
title: "Application Task 6"
author: ""
date: ""
output: 
  html_document: 
    keep_md: yes
---



## The Workflow

Due by 11:59 pm Sunday, Nov. 17th.

### Overview
Your task is to complete two of the four numbered items in Task 2. 

You will be submitting three items: [1] a README.md and [2] a report through GitHub, and [3] a reflection on Bb.

Note: This Application Task is based on Vincenzo Coia's STAT545 homework.

#### Evaluation

Tasks 1 and 3 will be evaluated using the [Meeting Preparation Grading Standards](https://sta518.github.io/syllabus/assessment/#meeting-preparation-1).
Your overall submission for Task 2 will each be evaluated using the [Application Tasks Grading Standards](https://sta518.github.io/syllabus/assessment/#application-tasks-1) (instead of each item within Task 2).

Your overall Application Task 6 grade will be based on the following criteria:

- Excellent (**E**): Each task earned an Excellent of Satisfactory, including one Excellent.
- Satisfactory (**S**): Each task earned a Satisfactory.
- Progressing (**P**): At least one task earning a Progressing.
- Incomplete (**I**): At least one task was not submit.

### Create Your `application06` Repo

GitHub Classroom will automatically make a repository for you, called `application06-your_github_username`, for you to work on your assignment.
Follow these instructions to get the repo:

1. Sign-in to [Bb](https://mybb.gvsu.edu)
2. Go to the **Application Task 6** assignment page.

Here, you will find a url leading to a page on GitHub Classroom.
Visit this page and follow the instructions.
When you obtain your repository, it should contain a copy of this `application06-instructions.md` file, a blank `README.md` file, and a starter `application06Rmd` file.

#### 1. Edit `README.md` 

Your task here is to edit the `README.md` file in your repository to contain a sample of GitHub-flavored markdown features.
Specifically, your README should contain a brief description as to what the repo is, so that an unknown visitor landing on the repo can orient themselves
You should also help the visitor navigate your repository (in whatever way you think is most appropriate).

Remember the resources you were directed to view during your work in the class activities and Meeting Preparations.
These are also organized in the [Additional Resources/Markdown](https://sta518.github.io/resources/markdown/) section of this site.

You can edit the README in your browser like we did in class, but I encourage you to experiment with editing it from within RStudio.
**FYI, this will be a private repo - only you and I will be able to see it.**

#### 2. Pick Two

##### 2.1 Writing functions for the `singer` data

Write one (or more) functions that do something useful to pieces of the [`singer`](https://github.com/JoeyBernhardt/singer/) data set.
It is logical to think about computing on the mini-data frames corresponding to the data for each specific country, location, year, ...
This would pair well with the prompt below about working with a nested data frame, as you could apply your function there.

Make it something you can't easily do with built-in functions.
Make it something that's not trivial to do with the simple dplyr verbs.
The linear regression functions we've done in class would be a good starting point.
You could generalize that to do quadratic regression (include a squared term) or use robust regression, using `MASS::rlm()` or `robustbase::lmrob()`.

##### 2.2 Work with the `singer` data

The `singer_locations` dataframe in the `singer` package contains geographical information stored in two different formats: 1. as a dirty variable named `city`; 2. as a latitude / longitude pair (stored in `latitude` and `longitude`, respectively).
The function `revgeocode` from the `ggmap` library allows you to retrieve some information for a pair (vector) of longitude, latitude (warning: notice the order in which you need to pass lat and long).
Read its manual page.

1. Use `purrr` to map latitude and longitude into human readable information on the band's origin places.
  Notice that `revgeocode(... , output = "more")` outputs a dataframe, while `revgeocode(... , output = "address")` returns a string - you have the option of dealing with nested dataframes.

  You will need to pay attention to two things:

  - Not all of the track have a latitude and longitude: what can we do with the missing information? (filtering, ...)
  - When we make a search through `revgeocode()` we do not always get a result.
    What can we do to avoid these errors?
    Look at `possibly()` in `purrr`.
    
2. Try to check whether the place in city corresponds to the information you retrieved.

3. Give a look to the [`leaflet`](https://rstudio.github.io/leaflet/) and plot some information about the bands.
  A snippet of code is provided below.


```r
singer_locations %>%  
  leaflet()  %>%   
  addTiles() %>%  
  addCircles(popup = ~artist_name)
```

##### 2.3 Work with a list

Work through and write up your own narrative from one of the two `purrr` tutorials created by Jenny Bryan:

- [Trump Android Tweets](https://jennybc.github.io/purrr-tutorial/ls08_trump-tweets.html)
- [Simplifying data from a list of GitHub users](https://jennybc.github.io/purrr-tutorial/ls02_map-extraction-advanced.html)

##### 2.4 Scrape and analyze the gender wage gap

Scrape the table of [gender wage gap by country](https://en.wikipedia.org/wiki/List_of_countries_by_male_to_female_income_ratio).
Save your code in an R script called `paygap.R`, write the data frame out to a csv file called `paygap.csv` using the `write_csv` function.
Store this file in the data folder.

For example, if your data frame is called `paygap`, you can use:


```r
write_csv(paygap, path = "data/paygap.csv")
```

Load `paygap.csv` in your R Markdown file.

Create a visualization similar to, though not necessarily exactly the same as, the one shown on the [Wikipedia page](https://en.wikipedia.org/wiki/Gender_pay_gap).
Interpret the plot.


#### 3. Reflection
  
After you have completed Tasks 1 and 2 go back to the **Application Task 6** assignment page on [Bb](https://mybb.gvsu.edu).
You will submit your reflection here that minimally includes:

- A clickable link to your Application Task 6 repository.
- A reflection on what was hard/easy, problems you came across and how you solved them, helpful tutorials you read, etc.
