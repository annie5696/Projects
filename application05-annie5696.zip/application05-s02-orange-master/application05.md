---
title: "Application 05 - Getting Started on The Final"
author: "Orange - Section 2"
date: "2019-11-03"
output: 
  html_document: 
    keep_md: yes
---



![](http://www.law.umich.edu/assets/exonerations/images/nationalregistry_logo.png)

> The Mission Of **The National Registry Of Exonerations** is to provide comprehensive information on exonerations of innocent criminal defendants in order to prevent future false convictions by learning from past errors.

The data covers about 2,500 exonerations with variables on race, age, crime, sentence, and multiple indicators of the circumstances of each release. A few considerations for research:

1. What types of crimes are most often exonerated? Is there a difference between races or state? Given a state, race, or crime, can we predict one of the other?
  
2. How are exonerations changing over time? Can we visually layer onmajor legislative milestones that could have affected these outcomes? 
  
3. What types of exonerations are typically occuring in each state, against each race, or with respect to each crime type? Are certain counties indicative of certain types of misconduct on the side of the law?

4. What are the poverty and population levels for counties with the most exonerations?

There is good opportunity to introduce outside data including county-level poverty or unemployment rates, longitude / latitude metrics for geospatial exploration, and the political climate during the year of sentencing and exoneration.  

There is also the possibility of looking at the number of exonerations as our outcome variable and poverty and population levels, political climate, year, and county as our predictor variables and see if we could come up with a sufficent model for modeling the number of exonerations per year for each county. 

Also, It could be interesting to look at the mean difference in number of exonerations between different races, crimes, or any other factors. 

## Data Exploration

Our dataset has 2509 observations and 18 variables. A lot to cover here, so we split our the explantations below.  


```r
# glimpse call was kicking out an error, so we used str
# glimpse(exonerations)

str(exonerations)
```

```
## Classes 'spec_tbl_df', 'tbl_df', 'tbl' and 'data.frame':	2509 obs. of  19 variables:
##  $ Last_Name      : chr  "Abbitt" "Abdal" "Abernathy" "Abney" ...
##  $ First_Name     : chr  "Joseph Lamont" "Warith Habib" "Christopher" "Quentin" ...
##  $ Age            : num  31 43 17 32 35 26 26 25 32 17 ...
##  $ Race           : chr  "Black" "Black" "White" "Black" ...
##  $ ST             : chr  "NC" "NY" "IL" "NY" ...
##  $ County_of_crime: chr  "Forsyth" "Erie" "Cook" "New York" ...
##  $ Tags           : chr  "CV, IO" "IO" "CIU, CV, H, IO" "CV" ...
##  $ Crime          : chr  "Child Sex Abuse" "Sexual Assault" "Murder" "Robbery" ...
##  $ Sentence       : chr  "Life" "20 to Life" "Life without parole" "20 to Life" ...
##  $ Convicted      : num  1995 1983 1987 2006 1994 ...
##  $ Exonerated     : num  2009 1999 2015 2012 2006 ...
##  $ DNA            : chr  "DNA" "DNA" "DNA" NA ...
##  $ *              : chr  NA NA NA NA ...
##  $ MWID           : chr  "MWID" "MWID" NA "MWID" ...
##  $ FX             : chr  NA NA "FC" NA ...
##  $ P/FA           : chr  NA NA "P/FA" NA ...
##  $ F/MFE          : chr  NA "F/MFE" NA NA ...
##  $ OM             : chr  NA "OM" "OM" NA ...
##  $ ILD            : chr  NA NA NA NA ...
##  - attr(*, "spec")=
##   .. cols(
##   ..   Last_Name = col_character(),
##   ..   First_Name = col_character(),
##   ..   Age = col_double(),
##   ..   Race = col_character(),
##   ..   ST = col_character(),
##   ..   County_of_crime = col_character(),
##   ..   Tags = col_character(),
##   ..   Crime = col_character(),
##   ..   Sentence = col_character(),
##   ..   Convicted = col_double(),
##   ..   Exonerated = col_double(),
##   ..   DNA = col_character(),
##   ..   `*` = col_character(),
##   ..   MWID = col_character(),
##   ..   FX = col_character(),
##   ..   `P/FA` = col_character(),
##   ..   `F/MFE` = col_character(),
##   ..   OM = col_character(),
##   ..   ILD = col_character()
##   .. )
```



### Exploration of Age, Race, ST, County 

#### Age: The exoneree's age on the date of the reported crime


![](application05_files/figure-html/explore-age, -1.png)<!-- -->

Looking at the graph above we can see that the distribution of an exoneree's age on the date of the reported crime is right skewed. This means that the exoneree's age on the date of the reported crime were typically greater than 20. There was also a person who had an age greater than 80 on the date of the reported crime. 


```
## # A tibble: 1 x 19
##   Last_Name First_Name   Age Race  ST    County_of_crime Tags  Crime
##   <chr>     <chr>      <dbl> <chr> <chr> <chr>           <chr> <chr>
## 1 Stevens   Ted           83 White F-DC  <NA>            FED   Offi…
## # … with 11 more variables: Sentence <chr>, Convicted <dbl>,
## #   Exonerated <dbl>, DNA <chr>, `*` <chr>, MWID <chr>, FX <chr>,
## #   `P/FA` <chr>, `F/MFE` <chr>, OM <chr>, ILD <chr>
```

I wanted to further look at observation who was an outlier in terms of the variable Age. He was convicted in 2008 and exonerated in 2009, he was never sentced, and he was exonerated for offical misconduct, and it was a federal case. Offical misconduct is when police, prosecutors, or other government officials significantly abused their authority or the judicial process in a manner that contributed to the exoneree's conviction. 

#### Race


```r
exonerations %>%
  group_by(Race) %>%
  summarise(count=n())
```

```
## # A tibble: 6 x 2
##   Race            count
##   <chr>           <int>
## 1 Asian              24
## 2 Black            1230
## 3 Hispanic          291
## 4 Native American    19
## 5 Other              15
## 6 White             930
```

```r
ggplot(data = exonerations, mapping = aes(x = Race)) +
  geom_bar( fill = "violet", stat="count") +
  theme_minimal()
```

![](application05_files/figure-html/explore-race-1.png)<!-- -->

Looking at the counts and the bar chart above we can see that the majority of people in this data set had a race of either Black or White. There were also quite a few observations that had a race of Hispanic, and not as manyt observations identifying as Native AMerican, Other, and Asian. 

To compare races with other information in this dataset it might be best to collaspe the categories of race into just Black, White, or Other. 

#### ST - State


```r
table(exonerations$ST)
```

```
## 
##    AK    AL    AR    AZ    CA    CO    CT    DC    DE  F-AL  F-AZ  F-CA 
##     8    27    10    21   197    11    23    17     3     1     3    11 
##  F-CT  F-DC  F-FL  F-IL  F-KY  F-LA  F-MA  F-MD  F-MI F-MIL  F-MN  F-MO 
##     2     4     6     6     1     6     3     5     3     6     1     4 
##  F-MT  F-ND  F-NJ  F-NM  F-NV  F-NY  F-OH  F-PA  F-SD  F-TN  F-TX  F-VA 
##     1     1     1     1     1    18     1     5     1     6     5     4 
##  F-WA  F-WI    FL    GA    GU    HI    IA    ID    IL    IN    KS    KY 
##     2     5    73    37     1     3    16     6   303    37    11    15 
##    LA    MA    MD    ME    MI    MN    MO    MS    MT    NC    ND    NE 
##    59    66    34     3    99    16    47    21    14    64     4     9 
##    NH    NJ    NM    NV    NY    OH    OK    OR    PA    PR    RI    SC 
##     1    38     7    13   265    83    37    19    81     6     6     7 
##    SD    TN    TX    UT    VA    VT    WA    WI    WV    WY 
##     5    21   358    18    52     2    50    57    10     4
```

Using the table() function we were able to see how many observations fall under each state. One thing that I noticed was that some states have "F-" in the begining of the state abbreviations. I thought this was really weird, also the county for these observations all had a direction for the county variable instead of an actual county. I googled what the "F-" represented and did not come up with a conclusive answer. I believe it is just for observations that were lacking in geographical information. I will continue to further investigate this pecularity. 

The table was a little messy so I wanted to filter down to states that had more than 20 observations to see if there were any trends withine Stat for the number of exonerations. 

```r
high_freq_sts <- exonerations %>%
  group_by(ST) %>%
  summarise(count=n()) %>%
  filter(count>20)

ggplot(high_freq_sts, aes(x = ST, y = count)) +
  geom_bar(stat = "identity", fill = "purple")
```

![](application05_files/figure-html/explore-ST1-1.png)<!-- -->

Here we can see that CA, IL, NY, and TX all have the most observations within this dataset. This could have something to do with the population sizes in these states, or possibly the large cities within these states such as Los Angeles, Chicago, New York, and Houston. Typically, in large cities you can see problems with income inequality and racial disparity.

Based on this graph it would be interesting to look at poverty or population data to look at the number of exonerations happening within a certain county or city. 

#### County_of_crime 


```r
high_freq_ctys <- exonerations %>%
  group_by(ST, County_of_crime) %>%
  summarise(count=n()) %>%
  filter(count>20)
high_freq_ctys
```

```
## # A tibble: 16 x 3
## # Groups:   ST [11]
##    ST    County_of_crime count
##    <chr> <chr>           <int>
##  1 CA    Kern               25
##  2 CA    Los Angeles        67
##  3 IL    Cook              240
##  4 LA    Orleans            24
##  5 MA    Suffolk            28
##  6 MD    Baltimore City     22
##  7 MI    Wayne              53
##  8 NY    Bronx              43
##  9 NY    Kings              74
## 10 NY    New York           40
## 11 NY    Queens             25
## 12 OH    Cuyahoga           30
## 13 PA    Philadelphia       38
## 14 TX    Dallas             60
## 15 TX    Harris            176
## 16 WI    Milwaukee          21
```

```r
ggplot(high_freq_ctys, aes(x = County_of_crime, y = count)) +
  geom_bar(stat = "identity", fill = "orange") +
theme(axis.text.x = element_text(angle = 90)) 
```

![](application05_files/figure-html/explore-County-1.png)<!-- -->

Looking at the table we can see that the counties that have the highest count of exonerations are within the states that we observed earlier such as CA, IL, NY, and TX.

Looking at the graph we can see that the county "Cook" has the highest amount of exonerations then any other county. Cook County is within Illinois. Again, this further peaks my interest in looking at the poverty and population levels of these counties. 

#####  DNA, *, MWID, FC


```r
#DNA, *, MWID, FX
exonerations %>%
  colnames()
```

```
##  [1] "Last_Name"       "First_Name"      "Age"            
##  [4] "Race"            "ST"              "County_of_crime"
##  [7] "Tags"            "Crime"           "Sentence"       
## [10] "Convicted"       "Exonerated"      "DNA"            
## [13] "*"               "MWID"            "FX"             
## [16] "P/FA"            "F/MFE"           "OM"             
## [19] "ILD"
```

```r
nrow(exonerations)
```

```
## [1] 2509
```

```r
ncol(exonerations)
```

```
## [1] 19
```

**The variable below represents factors contributing to exoneration **

> `DNA`: Whether the DNA was tested or not. (Values): `DNA` or `NA`

> `*`: An asterisk (* ) in the column to the right of the "DNA" column indicates post-conviction DNA evidence was not major factor to establishing innocence, and other non-DNA factors were essential to the exoneration and vice-versa. (Values): `*` or `NA`

>  `MWID`: Mistaken Witness Identification where at least one witness mistakenly identified the exoneree as a person the witness saw commit the crime. (Values): `MWID` or `NA`

>  `FX` : False Confession, the confession of crime was made falsely. (Values): `FC` or `NA`.


**Exploratory Analysis**



```r
exonerations %>%
  select(DNA,`*`,MWID,FX) %>%
  mutate_all(factor) %>% 
  summary()
```

```
##    DNA          *          MWID         FX      
##  DNA : 496   *   : 129   MWID: 715   FC  : 305  
##  NA's:2013   NA's:2380   NA's:1794   NA's:2204
```

> From the summary , we can see the total values among four columns, where there are many `NA` values. 


**As we can see there is a direct relationship between (*) and DNA, Lets find out how many exoneree were tested based on DNA or Other Factor else DNA**


```r
exonerations %>%
  group_by(`*`, DNA) %>% 
  count()
```

```
## # A tibble: 3 x 3
## # Groups:   *, DNA [3]
##   `*`   DNA       n
##   <chr> <chr> <int>
## 1 *     DNA     129
## 2 <NA>  DNA     367
## 3 <NA>  <NA>   2013
```

> From above we can see that, Total exoneree who was tested only based on DNA was 496(129+367) and Apart from only DNA was 129.


> Renaming `*` as `PrimaryType`
> Converting `FC` as `False Confession`
> Converting `*` as `Non DNA` in values for PrimaryType
> Now, Lets explore relationship between four variables 


```r
exonerations %>%
  select(DNA,`*`,MWID,FX) %>%
rename(PrimaryType =`*`) %>%
mutate(FX=replace(FX, FX=='FC', 'False Confession')) %>%
  mutate(PrimaryType=(ifelse(PrimaryType=="*", "Non DNA")))-> exo
head(exo)
```

```
## # A tibble: 6 x 4
##   DNA   PrimaryType MWID  FX              
##   <chr> <chr>       <chr> <chr>           
## 1 DNA   <NA>        MWID  <NA>            
## 2 DNA   <NA>        MWID  <NA>            
## 3 DNA   <NA>        <NA>  False Confession
## 4 <NA>  <NA>        MWID  <NA>            
## 5 <NA>  <NA>        <NA>  <NA>            
## 6 <NA>  <NA>        <NA>  <NA>
```

> In the above table, we rename the column name (*) to PrimaryType, change values FC to False Confession and leave rest as it is.


> Bargraph plot for False Witness and DNA Test

> Bar plot below showing the relation between False witness and DNA test.


```r
exo_data1 <- exo %>%
  dplyr::group_by(DNA) %>% 
  dplyr::mutate(count = n())
    ggplot(data = exo_data1, aes(x = DNA, fill = MWID))+ geom_bar(position = position_dodge()) +coord_flip()+ labs(title = "Exoneration based on False witness and DNA Test", x = "DNA Test", y = "count")+theme_minimal() +scale_fill_discrete(name = "False Witness") + theme(panel.border = element_blank(), text=element_text(size=11.5, family="Arial light"))
```

![](application05_files/figure-html/unnamed-chunk-6-1.png)<!-- -->

> Bar plot based on Primary Type (*) and DNA Test 


```r
    ggplot(data = exo_data1, aes(x = DNA, fill = PrimaryType))+ geom_bar(position = position_dodge()) +coord_flip()+ labs(title = "Exoneration based on PrimaryType and DNA Test", x = "DNA Test", y = "count")+theme_minimal() +scale_fill_discrete(name = "Based On Primary Type(*)") + theme(panel.border = element_blank(), text=element_text(size=11.5, family="Arial light"))
```

![](application05_files/figure-html/unnamed-chunk-7-1.png)<!-- -->


> DNA, MWID, FX, PrimaryType

> Summary count for all exoneree.


```r
 non_na<- exo_data1 %>%
gather(variable, ind, -count) %>%
   group_by(ind) %>% summarise(non_na_count = sum(!is.na(ind)))
non_na
```

```
## # A tibble: 5 x 2
##   ind              non_na_count
##   <chr>                   <int>
## 1 DNA                       496
## 2 False Confession          305
## 3 MWID                      715
## 4 Non DNA                   129
## 5 <NA>                        0
```

> The above summary shows the non `NA` values for Exoneration with coressponding factors considered.



```r
non_na %>% 
    ggplot(aes(x = ind , y =non_na_count)) + geom_col() + labs(title = "Total factor count in Exoneration", x = "Factors", y = "count")+theme_minimal() + theme(panel.border = element_blank(), text=element_text(size=11.5, family="calibri light")) + coord_flip()
```

![](application05_files/figure-html/unnamed-chunk-9-1.png)<!-- -->

### Exploration of P/FA, F/MFE, OM, ILD 


```r
jc_vars <- exonerations %>% 
  select("P/FA", "F/MFE", "OM", "ILD")
```

According to the code book site, these variables represent contributing factors for each exoneration, if applicable. 

#### P/FA: Perjury, False Accusation

> A person other than the exoneree committed perjury by making a false statement under oath that incriminated the exoneree in the crime for which the exoneree was later exonerated, or made a similar unsworn statement that would have been perjury if made under oath.

#### M/MFE - False or Misleading Forensic Evidence

> Exoneree's conviction was based at least in part on forensic information that was (1) caused by errors in forensic testing, (2) based on unreliable or unproven methods, (3) expressed with exaggerated and misleading confidence, or (4) fraudulent.

#### OM - Official Misconduct

>Police, prosecutors, or other government officials significantly abused their authority or the judicial process in a manner that contributed to the exoneree's conviction.

#### ILD - Inadequate Legal Defense

> The exonoree's lawyer at trial provided obviously and grossly inadequate representation.

These all provide insight into the reason for exoneration. Looking at the values, there are a lot of `NA` entries. 


```r
jc_vars %>% 
  mutate_all(factor) %>% 
  summary()
```

```
##    P/FA        F/MFE         OM         ILD      
##  P/FA:1464   F/MFE: 573   OM  :1349   ILD : 657  
##  NA's:1045   NA's :1936   NA's:1160   NA's:1852
```

Each column has the column name as an entry, so this is more of an indicator variable. We'll convert them for further analysis.


```r
jc_var_tidy <- jc_vars %>% 
  mutate(record = row_number()) %>% 
  gather(var, indicator, -record) %>% 
  mutate(indicator = if_else(is.na(indicator), 0, 1))
```

Checking for counts on these 4 flags, we see `Perjury / False Accusation` at the top with `Official Misconduct` a close second.
  
  
![](application05_files/figure-html/unnamed-chunk-13-1.png)<!-- -->

On average, we're seeing ~1.6 flags per record. So we're not seeing a mutually exclusive relationship between these variables. 

![](application05_files/figure-html/unnamed-chunk-14-1.png)<!-- -->

### Exploration of tags, crime, sentence, convicted, & exonerated

```r
exo <- read_csv("Data/Exonerations.csv")
```

#### tags

```r
exo <-exo %>%
  mutate(tagsVec = strsplit(gsub(" ","",Tags),",")) %>%
  mutate(timeDone = Exonerated- Convicted)

# I'm sure there's a better way to do this, but I couldn't find it
exo <- exo %>% rowwise() %>% mutate(A= 'A' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(CDC= 'CDC' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(CIU= 'CIU' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(CSH= 'CSH' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(CV= 'CV' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(F= 'F' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(FED= 'FED' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(H= 'H' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(IO= 'IO' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(JI= 'JI' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(M= 'M' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(NC= 'NC' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(P= 'P' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(PH= 'PH' %in% tagsVec)
exo <- exo %>% rowwise() %>% mutate(SBS= 'SBS' %in% tagsVec)

exo %>%
  select(Tags,A:SBS)
```

```
## Source: local data frame [2,509 x 16]
## Groups: <by row>
## 
## # A tibble: 2,509 x 16
##    Tags   A     CDC   CIU   CSH   CV    F     FED   H     IO    JI    M    
##    <chr>  <lgl> <lgl> <lgl> <lgl> <lgl> <lgl> <lgl> <lgl> <lgl> <lgl> <lgl>
##  1 CV, IO FALSE FALSE FALSE FALSE TRUE  FALSE FALSE FALSE TRUE  FALSE FALSE
##  2 IO     FALSE FALSE FALSE FALSE FALSE FALSE FALSE FALSE TRUE  FALSE FALSE
##  3 CIU, … FALSE FALSE TRUE  FALSE TRUE  FALSE FALSE TRUE  TRUE  FALSE FALSE
##  4 CV     FALSE FALSE FALSE FALSE TRUE  FALSE FALSE FALSE FALSE FALSE FALSE
##  5 NC, P  FALSE FALSE FALSE FALSE FALSE FALSE FALSE FALSE FALSE FALSE FALSE
##  6 H, P   FALSE FALSE FALSE FALSE FALSE FALSE FALSE TRUE  FALSE FALSE FALSE
##  7 F, NC… FALSE FALSE FALSE FALSE FALSE TRUE  FALSE FALSE FALSE FALSE FALSE
##  8 CIU, … FALSE FALSE TRUE  FALSE FALSE FALSE FALSE FALSE TRUE  FALSE FALSE
##  9 H      FALSE FALSE FALSE FALSE FALSE FALSE FALSE TRUE  FALSE FALSE FALSE
## 10 IO, NC FALSE FALSE FALSE FALSE FALSE FALSE FALSE FALSE TRUE  FALSE FALSE
## # … with 2,499 more rows, and 4 more variables: NC <lgl>, P <lgl>,
## #   PH <lgl>, SBS <lgl>
```

Tags came in as a list of comma-separated values, so I separated them out into a bool column for each possible tag that reads TRUE in rows containing that tag.  

```r
exo %>%
  select(Last_Name,First_Name,A:SBS) %>%
  pivot_longer(A:SBS,names_to="Tag",values_to = "Has") %>%
  ggplot(aes(x=Tag,y=as.numeric(Has),fill=Tag))+
  stat_summary(fun.y = sum, geom = "bar") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))+ ylab(
    "Count"
  )
```

![](application05_files/figure-html/unnamed-chunk-17-1.png)<!-- -->
The most common tags in this dataset are "H" for homicide, and "NC" for no crime. The entire list of what each tag means can be found [here](http://www.law.umich.edu/special/exoneration/Pages/detaillist.aspx#).

#### Cime

```r
exo %>%
  ggplot(aes(x=Crime, y=timeDone)) +
  geom_boxplot()+ 
  theme(axis.text.x = element_text(angle = 90, hjust = 1,vjust = 0))
```

![](application05_files/figure-html/unnamed-chunk-18-1.png)<!-- -->
This plot shows the spread of time spent between conviction and exoneration for each crime type in the data. Since this data only contains people exonerated of their crimes, those outliers on the top end are disturbing. 



```r
exo %>%
  group_by(TRUE) %>%
  summarise("Total Time"=sum(timeDone))
```

```
## Warning: Grouping rowwise data frame strips rowwise nature
```

```
## # A tibble: 1 x 2
##   `TRUE` `Total Time`
##   <lgl>         <dbl>
## 1 TRUE          27441
```
This shows the total amount of years spent in prison by individuals in the database exonerated of their crimes. 


```r
exo <-exo %>%
  mutate(min_sent = strsplit(Sentence," to ")[[1]][1]) %>%
  mutate(max_sent = strsplit(Sentence," to ")[[1]][2])
```


```r
getSentLength <- function(min_sent,max_sent){

  nonLockedSents = c("probation","not sentenced","unknown","community service","fine")
  if(tolower(min_sent) =="life"| tolower(min_sent)=="death" | tolower(min_sent)=="life without parole"){
    return(dyears(100));#treating life and death sentences as 100 years
  }
  else if(tolower(min_sent) %in% nonLockedSents){
    return(dyears(0)); #treating little half-punishments as 0 time
  }
  min_sent = strsplit(as.character(min_sent),split="and")[[1]][1]
  max_sent = strsplit(as.character(max_sent),split="and")[[1]][1]
  min_sentUnit = case_when(
      grepl("year", tolower(min_sent)) ~ "year",
      tolower(max_sent) == "life" ~ "year",
      grepl("month", tolower(min_sent)) ~ "month",
      grepl("week",tolower(min_sent)) ~ "week",
      grepl("day", tolower(min_sent)) ~ "day",
      TRUE ~ "NA"
  ) 
  max_sentUnit = case_when(
      grepl("year", tolower(max_sent)) ~ "year",
      grepl("month", tolower(max_sent)) ~ "month",
      grepl("week",tolower(max_sent)) ~ "week",
      grepl("day", tolower(max_sent)) ~ "day",
      TRUE ~ "NA"
  ) 
  
  if(min_sentUnit=="NA" & max_sentUnit!="NA"){
    min_sentUnit = max_sentUnit
  }
  
  min_sentN = strsplit(as.character(min_sent),split=" ")[[1]][1]
  max_sentN = strsplit(as.character(max_sent),split=" ")[[1]][1]
  
  min_sentDur = case_when(
    min_sentUnit=="year" ~ dyears(as.numeric(min_sentN)),
    min_sentUnit=="month" ~ ddays(30*as.numeric(min_sentN)),
    min_sentUnit=="week" ~ ddays(7*as.numeric(min_sentN)),
    min_sentUnit=="day" ~ ddays(as.numeric(min_sentN)),
    TRUE ~ ddays(0)
  )
  if(is.na(max_sent)){
    return(min_sentDur)
  }
  
  max_sentDur = case_when(
    max_sentUnit=="year" ~ dyears(as.numeric(max_sentN)),
    max_sentUnit=="month" ~ ddays(30*as.numeric(max_sentN)),
    max_sentUnit=="week" ~ ddays(7*as.numeric(max_sentN)),
    max_sentUnit=="day" ~ ddays(as.numeric(max_sentN)),
    TRUE ~ ddays(0)
  )
  return((max_sentDur+min_sentDur)/2)
}
suppressWarnings(
exo <- exo %>%
  mutate(sentLen = as.numeric(getSentLength(min_sent,max_sent)))
)
```
The sentence lengths were in string format, so some parsing was necessary to pull out the numeric duration of the sentencing. 



```r
exo %>%
  filter(sentLen/as.numeric(dyears(1))<101) %>%
  ggplot(aes(x=sentLen/as.numeric(dyears(1)))) +
  geom_histogram() +
  ylab("sentence years")
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

![](application05_files/figure-html/unnamed-chunk-22-1.png)<!-- -->

Any sentence that didn't involve time spent in jail or prison was given a value of 0, and any life or death sentence was 100 years. Those two options make up a decent chunk of the data.
