---
title: "Application Task 5"
author: ""
date: ""
output: 
  html_document: 
    keep_md: yes
---



## The Workflow

Due by 11:59 pm Sunday, Nov. 3rd.

### Overview
This is your Team Project proposal.
Your Team Project consists of you analyzing a data set of your own choosing and producing a "data product" to showcase your analysis.
This data product could be a report/data investigation (in the flavor of a [The Pudding](http://pudding.cool) investigation), an interactive app (we will learn about these soon), or other creative outlet.
The goal of this project is for you to demonstrate proficiency in the techniques we have covered in class (and beyond, if you like) and apply them to a novel data set in a meaningful way.

You will be submitting three items: a Team [1] README.md and [2] report through GitHub, and [3] an individual reflection on Bb.

#### Evaluation

All three Tasks 1 and 3 will be evaluated using the [Meeting Preparation Grading Standards](https://sta518.github.io/syllabus/assessment/#meeting-preparation-1).
The following four criterion will used to evaluate Task 2.

- Content: What is the quality of research and/or policy question and relevancy of data to those questions?
- Analysis plan: Are procedures explained correctly and thoroughly?
- Writing and Presentation: What is the quality of the writing and explanations?
- Creativity and Critical Thought - Is the project carefully thought out? Are the limitations carefully considered? Does it appear that time and effort went into the planning and implementation of the project proposal?

Each criterion will be assess using the following standards:

- An excellent will be earned for showing substantial effort and has only suggestions for improvement.
- A satisfactory will be earned for showing substantial effort and has a few comments for improvement or clarity.
- A progressing will be earned for showing substantial effort, but has room for improvement or clarity.
- An incomplete will be earned for lack of effort or missing components.

Your overall Application Task 4 grade will be based on the following criteria:

- Excellent (**E**): Each task earned an Excellent or Satisfactory, including one Excellent.
- Satisfactory (**S**): Each task earned a Satisfactory.
- Progressing (**P**): Each task earned a Satisfactory or Progressing.
- Incomplete (**I**): At least one task was not submit.

### Create Your `application05` Repo

GitHub Classroom will automatically make a repository for you, called `application05-your_github_team_name`, for you to work on your assignment.
Have one Team Member follow these instructions to get the repo:

1. Sign-in to [Bb](https://mybb.gvsu.edu)
2. Go to the **Application Task 5** assignment page.

Here, you will find a URL leading to a page on GitHub Classroom.
Visit this page and follow the instructions.
When you obtain your repository, it should contain a copy of this `application05-instructions.md` file, a blank `README.md` file, and a starter `application05Rmd` file.

A note about Teamwork: You are to complete this Application Task as a Team - all Team Members are expected to contribute equally to the completion of it.
Anyone judged to not have sufficiently contributed to the final product will have their final grade reduced.
While different Team Members have different backgrounds and abilities, it is the responsibility of every Team Member to understand how and why all the approaches in your project will work.
In your individual reflections, you will be asked to provide feedback for each Team Member's contributions (including yourself) and I can verify this by reviewing commits from different Team Members.

A note about collaboration: Since you are completing this as a Team, you will encounter merge conflicts and other issues will arise.
This is fine and you (and I) will figure them out together.
Remember the workflow: commit and push often, and ask questions when stuck.
Also, feel free to experiment with [branches](https://happygitwithr.com/git-branches.html) (remember these from the beginning of the semester?).

#### 1. Edit `README.md` 

Your task here is to edit the `README.md` file in your repository to contain a sample of GitHub-flavored markdown features.
Specifically, your README should contain a brief description as to what the repo is, so that an unknown visitor landing on the repo can orient themselves
You should also help the visitor navigate your repository (in whatever way you think is most appropriate).

Remember the resources you were directed to view during your work in the class activities and Meeting Preparations.
These are also organized in the [Additional Resources/Markdown](https://sta518.github.io/resources/markdown/) section of this site.

You can edit the README in your browser like we did in class, but I encourage you to experiment with editing it from within RStudio.
**FYI, this will be a private repo - only you, your Team Members, and I will be able to see it.**

#### 2. Project Proposal

##### Data

To have the greatest chance of success with your Team Project, it is important to have a manageable data set.
This means that the data that you choose should be readily accessible and large enough that multiple relationships can be explored.
As such, your data set should have at least 50 observations and 10 to 20 variables (exceptions can be made, but you will need to explain in *great detail* why you feel that your Team deserves an exception).
The data set should also include categorical variables, discrete numerical variables, and continuous numerical variables.

Some resources that you may choose to search for data include:

- Jeremy Singer-Vine's (of BuzzFeed) [Data is Plural](https://docs.google.com/spreadsheets/d/1wZhPLMCHKJvwOkP4juclhjFgqIY8fQFMemwKL2c64vk/edit#gid=0) spreadsheet of data sets
- kaggle's [data sets](https://www.kaggle.com/datasets)

Since all analyses must be done in RStudio, make sure that you are able to load your date into RStudio.
This can be tricky depending on the source.
If you are having trouble, ask for help before it is too late.

You cannot reuse data sets used in class activities or other application tasks.

##### Report

You can treat this as a draft of the introduction and data analysis plan sections of your Team Project.
Your report should be brief, but descriptive enough to provide your instructor with a clear idea of your project.
Be sure to introduce your general research question and your data (where it came from, how it was collected, what are the cases, what are the variables, etc.).
Also, include:

- Any outcome and predictors variables you will use to answer your question.
- Describe any comparison groups you will use, if applicable.
- Provide some very preliminary exploratory data analysis, including some summary statistics and visualizations, along with some explanation on how they help you learn more about your data. You do not need to do anything exhaustive here, but this will provide you with a basic idea if your data is sufficient and or if you need to find any additional data. (You can update these later as you work on your project.)
- What statistical method(s) that you believe will be useful in answering your question(s). (You can update these later as you work on your project.)

Place your data in a `/data` folder, add dimensions and codebook to the README in your repo.
Also, provide a `glimpse` of your data in your report.

#### 3. Reflection
  
After you have completed Tasks 1 and 2 go back to the **Application Task 5** assignment page on [Bb](https://mybb.gvsu.edu).
Each member will submit an individual reflection that minimally includes:

- A clickable link to your Application Task 5 repository.
- Rate each Team Member's contribution (yourself included) on either "Poor", "Okay", or "Great", then provide rational/explanation for your rating. I will anonymize and summarize these for each member.
- A reflection on what was hard/easy, problems you came across and how you solved them, helpful tutorials you read, etc.  Describe specific contributions you have made to the success of the Team.  Also, describe what you could do, if anything, to better contribute to the success of the Team.
