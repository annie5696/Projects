# application05 - STA518 FAL19
This repo contains the following information about the Application 5:
1. [Instructions](https://github.com/sta518/application05-s02-orange/blob/master/application05-instructions.md) 
2. [R Markdown Document](https://github.com/sta518/application05-s02-orange/blob/master/application05.Rmd)
3. [This readme file](https://github.com/sta518/application05-s02-orange/edit/master/README.md)

![](http://www.law.umich.edu/assets/exonerations/images/nationalregistry_logo.png)

> The Mission Of **The National Registry Of Exonerations** is to provide comprehensive information on exonerations of innocent criminal defendants in order to prevent future false convictions by learning from past errors.

The data covers about 2,500 exonerations with variables on race, age, crime, sentence, and multiple indicators of the circumstances of each release. A few considerations for research:

1. What types of crimes are most often exonerated? Is there a difference between races or state? Given a state, race, or crime, can we predict one of the other?
  
2. How are exonerations changing over time? Can we visually layer onmajor legislative milestones that could have affected these outcomes? 
  
3. What types of exonerations are typically occuring in each state, against each race, or with respect to each crime type? Are certain counties indicative of certain types of misconduct on the side of the law?

4. Given which factor count, there is a highest and lowest number of exenornation occured ? Based upon those count compare the DNA and Non DNA cases? 

5. What are the poverty and population levels for counties with the most exonerations?



